"""
🎓 Pynote - Dashboard coloré avec sauvegarde des identifiants
"""

import os
import sys
import json
import csv
import urllib.request
import webbrowser
from pathlib import Path
from datetime import datetime, timedelta, date
from dotenv import load_dotenv

import pronotepy
from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, Vertical, ScrollableContainer, Grid
from textual.widgets import (
    Header, Footer, Static, Button, Label, Input, Rule, ProgressBar, Checkbox, Switch,
    DataTable, Select,
)
from rich.text import Text
from textual.screen import Screen
from textual.binding import Binding
from textual import work

load_dotenv()

# Compatibilité proxy scolaire
try:
    import truststore
    truststore.inject_into_ssl()
except ImportError:
    pass

# ═══════════════════════════════════════════════════════════════════════════════
# VERSION ET MISE À JOUR
# ═══════════════════════════════════════════════════════════════════════════════

APP_VERSION = "2.0.0"
APP_NAME = "Pynote"

# URL du site de mise à jour
UPDATE_URL = "https://cours.cmarbel15.xyz/Pynote/version.json"
DOWNLOAD_URL = "https://cours.cmarbel15.xyz/Pynote/Pynote"
LICENSE_URL = "https://cours.cmarbel15.xyz/Pynote/Licence-Pynote"

# Fichiers de sauvegarde
CREDENTIALS_FILE = Path.home() / ".pynote_credentials.json"
CONFIG_FILE = Path.home() / ".pynote_config.json"
LICENSE_FILE = Path.home() / ".pynote_license_accepted"
CACHE_FILE = Path.home() / ".pynote_cache.json"

# ═══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

SPARKLINE_CHARS = "▁▂▃▄▅▆▇█"
BAR_CHARS = "█"
BAR_HALF = "▌"

def bar_chart(subjects: dict, max_width: int = 30) -> str:
    """Génère un graphique en barres horizontales ASCII des moyennes par matière."""
    if not subjects:
        return ""
    lines = []
    max_val = 20.0
    sorted_subjs = sorted(subjects.items(), key=lambda x: x[1], reverse=True)
    for subj, avg in sorted_subjs:
        bar_len = int((avg / max_val) * max_width)
        half = (avg / max_val) * max_width - bar_len >= 0.5
        bar = BAR_CHARS * bar_len + (BAR_HALF if half else "")
        if avg >= 14:
            color = "green"
        elif avg >= 10:
            color = "yellow"
        else:
            color = "red"
        name = subj[:14].ljust(14)
        lines.append(f"  {name} [{color}]{bar}[/] {avg:.1f}")
    return "\n".join(lines)


def export_bulletin_html(client, period) -> str:
    """Génère un bulletin HTML et retourne le chemin du fichier."""
    period_name = period.name if period.name else "Période"
    avg = period.overall_average if hasattr(period, 'overall_average') else "?"
    class_avg = period.class_overall_average if hasattr(period, 'class_overall_average') else "?"
    
    # Moyennes par matière
    averages_html = ""
    if hasattr(period, 'averages') and period.averages:
        for a in period.averages:
            subj = a.subject.name if a.subject else "?"
            stu = str(a.student) if a.student else "?"
            cls = str(a.class_average) if a.class_average else "?"
            out = str(a.out_of) if a.out_of else "20"
            try:
                pct = float(str(stu).replace(",", ".")) / float(str(out).replace(",", "."))
                if pct >= 0.7:
                    color = "#27ae60"
                elif pct >= 0.5:
                    color = "#f39c12"
                else:
                    color = "#e74c3c"
            except (ValueError, ZeroDivisionError):
                color = "#95a5a6"
            averages_html += f"""
            <tr>
                <td style="font-weight:bold">{subj}</td>
                <td style="color:{color};font-weight:bold">{stu}/{out}</td>
                <td>{cls}</td>
            </tr>"""
    
    # Notes
    notes_html = ""
    if hasattr(period, 'grades') and period.grades:
        for g in sorted(period.grades, key=lambda x: x.date if x.date else date.min, reverse=True):
            subj = g.subject.name if g.subject else "?"
            val = str(g.grade) if g.grade else "?"
            out = str(g.out_of) if g.out_of else "20"
            dt = g.date.strftime("%d/%m/%Y") if g.date else "?"
            coef = str(g.coefficient) if g.coefficient else "1"
            try:
                pct = float(str(val).replace(",", ".")) / float(str(out).replace(",", "."))
                if pct >= 0.7:
                    color = "#27ae60"
                elif pct >= 0.5:
                    color = "#f39c12"
                else:
                    color = "#e74c3c"
            except (ValueError, ZeroDivisionError):
                color = "#95a5a6"
            notes_html += f"""
            <tr>
                <td>{dt}</td>
                <td style="font-weight:bold">{subj}</td>
                <td style="color:{color};font-weight:bold">{val}/{out}</td>
                <td>{coef}</td>
            </tr>"""
    
    html = f"""<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Bulletin Pynote - {period_name}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, sans-serif; background: #1a1a2e; color: #e0e0e0; padding: 30px; }}
        .container {{ max-width: 900px; margin: 0 auto; }}
        .header {{ background: linear-gradient(135deg, #667eea, #764ba2); padding: 30px; border-radius: 15px; text-align: center; margin-bottom: 25px; }}
        .header h1 {{ font-size: 28px; color: white; }}
        .header p {{ color: rgba(255,255,255,0.8); margin-top: 8px; }}
        .card {{ background: #16213e; border-radius: 12px; padding: 20px; margin-bottom: 20px; border: 1px solid #0f3460; }}
        .card h2 {{ color: #667eea; margin-bottom: 15px; font-size: 18px; }}
        .avg-big {{ font-size: 42px; font-weight: bold; text-align: center; padding: 20px; }}
        .avg-row {{ display: flex; justify-content: center; gap: 40px; text-align: center; }}
        .avg-item span {{ display: block; font-size: 12px; color: #888; }}
        table {{ width: 100%; border-collapse: collapse; }}
        th {{ text-align: left; padding: 10px; border-bottom: 2px solid #0f3460; color: #667eea; font-size: 13px; }}
        td {{ padding: 8px 10px; border-bottom: 1px solid #0f3460; }}
        tr:hover {{ background: rgba(102, 126, 234, 0.1); }}
        .footer {{ text-align: center; color: #555; margin-top: 30px; font-size: 12px; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎓 Bulletin Pynote</h1>
            <p>{period_name} — Généré le {datetime.now().strftime('%d/%m/%Y à %H:%M')}</p>
        </div>
        
        <div class="card">
            <h2>📊 Moyenne Générale</h2>
            <div class="avg-row">
                <div class="avg-item">
                    <div class="avg-big" style="color:#667eea">{avg}</div>
                    <span>Ta moyenne</span>
                </div>
                <div class="avg-item">
                    <div class="avg-big" style="color:#888;font-size:28px">{class_avg}</div>
                    <span>Moyenne de classe</span>
                </div>
            </div>
        </div>
        
        <div class="card">
            <h2>📚 Moyennes par Matière</h2>
            <table>
                <tr><th>Matière</th><th>Ta note</th><th>Classe</th></tr>
                {averages_html}
            </table>
        </div>
        
        <div class="card">
            <h2>📝 Détail des Notes</h2>
            <table>
                <tr><th>Date</th><th>Matière</th><th>Note</th><th>Coef</th></tr>
                {notes_html}
            </table>
        </div>
        
        <div class="footer">
            Généré par Pynote v{APP_VERSION} — cours.cmarbel15.xyz
        </div>
    </div>
</body>
</html>"""
    
    filepath = Path.home() / f"pynote_bulletin_{period_name.replace(' ', '_')}.html"
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(html)
    return str(filepath)


def sparkline(values: list, max_val: float = 20.0) -> str:
    """Génère un sparkline ASCII à partir d'une liste de valeurs."""
    if not values:
        return ""
    chars = []
    for v in values:
        idx = int((v / max_val) * (len(SPARKLINE_CHARS) - 1))
        idx = max(0, min(idx, len(SPARKLINE_CHARS) - 1))
        chars.append(SPARKLINE_CHARS[idx])
    return "".join(chars)

def save_cache(data: dict) -> None:
    """Sauvegarde le cache local (pour notifications de changements)."""
    with open(CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, default=str)

def load_cache() -> dict:
    if CACHE_FILE.exists():
        try:
            with open(CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def export_notes_csv(grades: list, filepath: str) -> None:
    """Exporte les notes en CSV."""
    with open(filepath, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["Date", "Matière", "Note", "Sur", "Coefficient", "Moyenne classe", "Min", "Max"])
        for g in grades:
            writer.writerow([
                str(g.date) if hasattr(g, 'date') and g.date else "",
                g.subject.name if g.subject else "?",
                str(g.grade) if g.grade else "",
                str(g.out_of) if g.out_of else "20",
                str(g.coefficient) if g.coefficient else "1",
                str(g.average) if hasattr(g, 'average') and g.average else "",
                str(g.min) if hasattr(g, 'min') and g.min else "",
                str(g.max) if hasattr(g, 'max') and g.max else "",
            ])

def export_notes_json(grades: list, filepath: str) -> None:
    """Exporte les notes en JSON."""
    data = []
    for g in grades:
        data.append({
            "date": str(g.date) if hasattr(g, 'date') and g.date else None,
            "subject": g.subject.name if g.subject else "?",
            "grade": str(g.grade) if g.grade else None,
            "out_of": str(g.out_of) if g.out_of else "20",
            "coefficient": str(g.coefficient) if g.coefficient else "1",
            "average": str(g.average) if hasattr(g, 'average') and g.average else None,
            "min": str(g.min) if hasattr(g, 'min') and g.min else None,
            "max": str(g.max) if hasattr(g, 'max') and g.max else None,
        })
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def check_for_update() -> dict:
    """
    Vérifie si une mise à jour est disponible.
    Retourne un dict avec les infos de mise à jour ou None si erreur.
    """
    try:
        req = urllib.request.Request(
            UPDATE_URL,
            headers={'User-Agent': f'{APP_NAME}/{APP_VERSION}'}
        )
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode('utf-8'))
            
            remote_version = data.get("version", "0.0.0")
            
            # Comparer les versions
            local_parts = [int(x) for x in APP_VERSION.split(".")]
            remote_parts = [int(x) for x in remote_version.split(".")]
            
            update_available = remote_parts > local_parts
            
            return {
                "update_available": update_available,
                "current_version": APP_VERSION,
                "latest_version": remote_version,
                "changelog": data.get("changelog", ""),
                "download_url": data.get("download_url", DOWNLOAD_URL),
                "release_date": data.get("release_date", ""),
            }
    except Exception as e:
        return {
            "update_available": False,
            "current_version": APP_VERSION,
            "error": str(e)
        }


def open_download_page(url: str = None) -> bool:
    """Ouvre la page de téléchargement dans le navigateur."""
    try:
        webbrowser.open(url or DOWNLOAD_URL)
        return True
    except Exception:
        return False


def save_credentials(url: str, username: str, password: str) -> None:
    """Sauvegarde les identifiants"""
    data = {"url": url, "username": username, "password": password}
    with open(CREDENTIALS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f)


def load_credentials() -> dict:
    """Charge les identifiants sauvegardés"""
    if CREDENTIALS_FILE.exists():
        try:
            with open(CREDENTIALS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"url": "", "username": "", "password": ""}


def delete_credentials() -> None:
    """Supprime les identifiants sauvegardés"""
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()


def save_config(config: dict) -> None:
    """Sauvegarde la configuration"""
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f)


def load_config() -> dict:
    """Charge la configuration"""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def config_exists() -> bool:
    """Vérifie si la configuration existe"""
    return CONFIG_FILE.exists()


def is_license_accepted() -> bool:
    """Vérifie si la licence a été acceptée"""
    return LICENSE_FILE.exists()


def accept_license() -> None:
    """Marque la licence comme acceptée"""
    with open(LICENSE_FILE, "w", encoding="utf-8") as f:
        f.write("accepted")


def fetch_license_text() -> str:
    """Récupère le texte de la licence depuis le serveur"""
    try:
        req = urllib.request.Request(
            LICENSE_URL,
            headers={'User-Agent': f'{APP_NAME}/{APP_VERSION}'}
        )
        with urllib.request.urlopen(req, timeout=10) as response:
            return response.read().decode('utf-8')
    except Exception as e:
        return f"Impossible de charger la licence.\nErreur: {e}\n\nVeuillez vérifier votre connexion internet."


# ═══════════════════════════════════════════════════════════════════════════════
# WIDGETS DASHBOARD
# ═══════════════════════════════════════════════════════════════════════════════

class DashboardCard(Static):
    """Carte colorée du dashboard"""
    
    def __init__(self, title: str, icon: str, btn_id: str, color: str = "primary", **kwargs):
        super().__init__(**kwargs)
        self.title_text = title
        self.icon = icon
        self.btn_id = btn_id
        self.color = color
        self.add_class(f"card-{color}")

    def compose(self) -> ComposeResult:
        yield Static(f"{self.icon} {self.title_text}", classes="card-title")
        yield Static("Chargement...", classes="card-content", id=f"content-{self.btn_id}")
        yield Button("Voir détails →", id=self.btn_id, classes="card-btn")


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRAN DE LICENCE
# ═══════════════════════════════════════════════════════════════════════════════

class LicenseScreen(Screen):
    """Écran d'acceptation de la licence au premier lancement"""

    CSS = """
    LicenseScreen {
        align: center middle;
        background: $surface;
    }
    
    #license-container {
        width: 90;
        height: auto;
        max-height: 95%;
    }
    
    #license-header {
        width: 100%;
        height: 5;
        background: $warning;
        border: round $warning;
        margin-bottom: 1;
    }
    
    #license-title {
        text-align: center;
        width: 100%;
        text-style: bold;
        color: $text;
        padding-top: 1;
    }
    
    #license-subtitle {
        text-align: center;
        width: 100%;
        color: $text-muted;
    }
    
    #license-info {
        width: 100%;
        height: auto;
        background: $panel;
        border: round $warning-darken-1;
        padding: 2;
        content-align: center middle;
    }
    
    #license-link {
        text-align: center;
        width: 100%;
        color: $primary;
        text-style: bold;
        margin: 1 0;
    }
    
    #license-note {
        text-align: center;
        width: 100%;
        color: $text-muted;
    }
    
    #btn-open-license {
        margin: 1 2;
        min-width: 30;
    }
    
    #license-buttons {
        layout: horizontal;
        height: auto;
        width: 100%;
        margin-top: 1;
        align: center middle;
    }
    
    .license-btn {
        margin: 0 2;
        min-width: 25;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="license-container"):
            with Vertical(id="license-header"):
                yield Static("📜 LICENCE PYNOTE", id="license-title")
                yield Static("Veuillez lire et accepter la licence", id="license-subtitle")
            
            with Vertical(id="license-info"):
                yield Static("📄 Lien vers la licence :", id="license-note")
                yield Static(f"🔗 {LICENSE_URL}", id="license-link")
                yield Button("🌐 Ouvrir dans le navigateur", id="btn-open-license")
            
            with Horizontal(id="license-buttons"):
                yield Button("❌ Refuser", id="btn-license-refuse", classes="license-btn", variant="error")
                yield Button("✅ J'accepte la licence", id="btn-license-accept", classes="license-btn", variant="success")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-open-license":
            webbrowser.open(LICENSE_URL)
            self.notify("🌐 Ouverture du navigateur...")
        elif event.button.id == "btn-license-accept":
            accept_license()
            self.app.pop_screen()
            self.app.push_screen("login")
        elif event.button.id == "btn-license-refuse":
            self.app.exit()


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRAN DE CONNEXION
# ═══════════════════════════════════════════════════════════════════════════════

class LoginScreen(Screen):
    """Connexion avec sauvegarde"""

    CSS = """
    LoginScreen {
        align: center middle;
        background: $surface;
        overflow-y: auto;
    }
    
    #login-container {
        width: 80;
        height: auto;
        min-height: 20;
        max-height: 95%;
        padding: 1;
    }
    
    #login-header {
        width: 100%;
        height: 5;
        background: $primary;
        border: round $primary;
        margin-bottom: 1;
    }
    
    #login-icon {
        display: none;
    }
    
    #login-title {
        text-align: center;
        width: 100%;
        text-style: bold;
        color: $text;
    }
    
    #login-subtitle {
        text-align: center;
        width: 100%;
        color: $text-muted;
    }
    
    #login-form {
        width: 100%;
        height: auto;
        background: $panel;
        border: round $primary-darken-1;
        padding: 1 2;
    }
    
    .field-row {
        layout: horizontal;
        height: auto;
        width: 100%;
        margin-bottom: 1;
    }
    
    .field-label {
        color: $primary;
        text-style: bold;
        width: 20;
        padding-top: 1;
    }
    
    .field-input {
        width: 1fr;
    }
    
    #action-row {
        layout: horizontal;
        height: auto;
        width: 100%;
        margin-top: 1;
        align: left middle;
    }
    
    #save-check {
        width: auto;
    }
    
    #btn-connect {
        width: auto;
        min-width: 20;
        margin-left: 2;
    }
    
    #status {
        text-align: center;
        height: 2;
        margin-top: 1;
    }
    
    .status-error { color: $error; }
    .status-loading { color: $warning; }
    .status-success { color: $success; }
    
    #login-footer {
        text-align: center;
        color: $text-muted;
        margin-top: 1;
    }
    """

    def compose(self) -> ComposeResult:
        creds = load_credentials()
        env_url = os.getenv("PRONOTE_URL", "")
        env_user = os.getenv("PRONOTE_USERNAME", "")
        env_pass = os.getenv("PRONOTE_PASSWORD", "")
        
        url = creds.get("url") or env_url
        user = creds.get("username") or env_user
        pwd = creds.get("password") or env_pass
        
        with Vertical(id="login-container"):
            with Vertical(id="login-header"):
                yield Static("🎓", id="login-icon")
                yield Static("🎓 PYNOTE", id="login-title")
                yield Static("Connectez-vous à Pronote", id="login-subtitle")
            
            with Vertical(id="login-form"):
                with Horizontal(classes="field-row"):
                    yield Label("🌐 URL", classes="field-label")
                    yield Input(placeholder="https://..../pronote/eleve.html?login=true", id="url", value=url, classes="field-input")
                
                with Horizontal(classes="field-row"):
                    yield Label("👤 Identifiant", classes="field-label")
                    yield Input(placeholder="Votre identifiant", id="user", value=user, classes="field-input")
                
                with Horizontal(classes="field-row"):
                    yield Label("🔒 Mot de passe", classes="field-label")
                    yield Input(placeholder="••••••••", id="pwd", password=True, value=pwd, classes="field-input")
                
                with Horizontal(id="action-row"):
                    yield Checkbox("💾 Se souvenir", id="save-check", value=bool(creds.get("url")))
                    yield Button("🚀 Connexion", id="btn-connect", variant="success")
                
                yield Static("", id="status")
            
            yield Static("🔐 Stockage local sécurisé", id="login-footer")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-connect":
            self._login()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        self._login()

    def _login(self) -> None:
        url = self.query_one("#url", Input).value.strip()
        user = self.query_one("#user", Input).value.strip()
        pwd = self.query_one("#pwd", Input).value
        save = self.query_one("#save-check", Checkbox).value
        status = self.query_one("#status", Static)
        
        if not all([url, user, pwd]):
            status.remove_class("status-loading", "status-success")
            status.add_class("status-error")
            status.update("❌ Veuillez remplir tous les champs")
            return
        
        status.remove_class("status-error", "status-success")
        status.add_class("status-loading")
        status.update("⏳ Connexion en cours...")
        
        self._do_login(url, user, pwd, save)

    @work(thread=True)
    def _do_login(self, url: str, user: str, pwd: str, save: bool) -> None:
        try:
            client = pronotepy.Client(url, username=user, password=pwd)
            if client.logged_in:
                # Sauvegarder si demandé
                if save:
                    save_credentials(url, user, pwd)
                else:
                    delete_credentials()
                
                self.app.client = client
                self.app.call_from_thread(self._success)
            else:
                self.app.call_from_thread(self._error, "Identifiants incorrects")
        except pronotepy.ENTLoginError as e:
            self.app.call_from_thread(self._error, f"Erreur ENT: {str(e)[:35]}")
        except pronotepy.PronoteAPIError as e:
            # Erreurs spécifiques de l'API Pronote
            error_msg = str(e)
            if "23" in error_msg:
                self.app.call_from_thread(self._error, "Session expirée, réessayez")
            else:
                self.app.call_from_thread(self._error, f"Erreur Pronote: {error_msg[:30]}")
        except Exception as e:
            error_str = str(e)
            if "23" in error_str:
                self.app.call_from_thread(self._error, "Trop de connexions, patiente...")
            else:
                self.app.call_from_thread(self._error, error_str[:40])

    def _success(self) -> None:
        status = self.query_one("#status", Static)
        status.remove_class("status-loading", "status-error")
        status.add_class("status-success")
        status.update("✅ Connexion réussie !")
        # Vérifier si la config existe
        if config_exists():
            self.app.push_screen("dashboard")
        else:
            self.app.push_screen("config")

    def _error(self, msg: str) -> None:
        status = self.query_one("#status", Static)
        status.remove_class("status-loading", "status-success")
        status.add_class("status-error")
        status.update(f"❌ {msg}")


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRAN DE CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

class ConfigScreen(Screen):
    """Configuration initiale"""

    CSS = """
    ConfigScreen {
        align: center middle;
        background: $surface;
    }
    
    #config-container {
        width: 65;
        height: auto;
    }
    
    #config-header {
        width: 100%;
        height: 5;
        background: $secondary;
        border: round $secondary;
        margin-bottom: 1;
    }
    
    #config-icon {
        text-align: center;
        width: 100%;
        color: $text;
    }
    
    #config-title {
        text-align: center;
        width: 100%;
        text-style: bold;
        color: $text;
    }
    
    #config-form {
        width: 100%;
        height: auto;
        background: $panel;
        border: round $secondary-darken-1;
        padding: 2;
    }
    
    .config-question {
        text-align: center;
        margin-bottom: 1;
    }
    
    .config-buttons {
        height: auto;
        margin-top: 1;
    }
    
    .config-btn {
        width: 50%;
        margin: 0 1;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="config-container"):
            with Vertical(id="config-header"):
                yield Static("⚙️", id="config-icon")
                yield Static("CONFIGURATION", id="config-title")
            
            with Vertical(id="config-form"):
                yield Static("📚 Comment sont organisées tes notes ?", classes="config-question")
                yield Static("(Trimestres ou Semestres)", classes="config-question")
                
                with Horizontal(classes="config-buttons"):
                    yield Button("📅 Trimestres", id="btn-trimestre", variant="primary", classes="config-btn")
                    yield Button("📅 Semestres", id="btn-semestre", variant="success", classes="config-btn")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-trimestre":
            save_config({"period_type": "trimestre"})
            self.app.config = {"period_type": "trimestre"}
            self.app.push_screen("dashboard")
        elif event.button.id == "btn-semestre":
            save_config({"period_type": "semestre"})
            self.app.config = {"period_type": "semestre"}
            self.app.push_screen("dashboard")


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRAN DASHBOARD
# ═══════════════════════════════════════════════════════════════════════════════

class DashboardScreen(Screen):
    """Dashboard coloré"""

    BINDINGS = [
        Binding("r", "refresh", "Actualiser"),
        Binding("s", "settings", "Paramètres"),
        Binding("escape", "logout", "Déconnexion"),
    ]

    CSS = """
    DashboardScreen { layout: vertical; background: $surface; }
    
    #update-bar {
        height: 5;
        background: $warning;
        padding: 1 3;
        layout: horizontal;
        align: center middle;
        display: none;
    }
    
    #update-bar.visible {
        display: block;
    }
    
    #update-bar #update-text {
        width: 1fr;
        color: $text;
        text-style: bold;
        padding-right: 2;
    }
    
    #update-bar Button {
        margin-left: 1;
        min-width: 16;
    }
    
    #update-bar #btn-download-update {
        background: $success;
    }
    
    #update-bar #btn-dismiss-update {
        background: $error;
        min-width: 10;
    }
    
    #welcome-bar {
        height: 5;
        background: $primary;
        padding: 1 2;
        layout: horizontal;
        align: center middle;
    }
    
    #welcome-text {
        text-style: bold;
        color: $text;
        width: auto;
    }
    
    #welcome-date {
        color: $text-muted;
        width: 1fr;
        padding-left: 2;
    }
    
    #btn-settings-header {
        background: white;
        color: $primary;
        border: thick white;
        min-width: 20;
        height: 3;
        text-style: bold;
    }
    
    #btn-settings-header:hover {
        background: $primary-lighten-3;
        color: white;
    }
    
    #dashboard-grid {
        layout: grid;
        grid-size: 3 2;
        grid-gutter: 2;
        padding: 2;
        height: 1fr;
        overflow-y: auto;
    }
    
    /* Cartes colorées */
    DashboardCard {
        height: 100%;
        padding: 1;
        background: $panel;
    }
    
    .card-blue {
        border: thick $primary;
        border-title-color: $primary;
    }
    
    .card-green {
        border: thick $success;
        border-title-color: $success;
    }
    
    .card-orange {
        border: thick $warning;
        border-title-color: $warning;
    }
    
    .card-red {
        border: thick $error;
        border-title-color: $error;
    }
    
    .card-purple {
        border: thick $accent;
        border-title-color: $accent;
    }
    
    .card-title {
        text-style: bold;
        padding-bottom: 1;
        margin-bottom: 1;
    }
    
    .card-blue .card-title { color: $primary; border-bottom: solid $primary; }
    .card-green .card-title { color: $success; border-bottom: solid $success; }
    .card-orange .card-title { color: $warning; border-bottom: solid $warning; }
    .card-red .card-title { color: $error; border-bottom: solid $error; }
    .card-purple .card-title { color: $accent; border-bottom: solid $accent; }
    
    .card-content {
        height: 1fr;
        overflow: auto;
    }
    
    .card-btn {
        dock: bottom;
        width: 100%;
        margin-top: 1;
    }
    
    .card-blue .card-btn { background: $primary; }
    .card-green .card-btn { background: $success; }
    .card-orange .card-btn { background: $warning; }
    .card-red .card-btn { background: $error; }
    
    /* Contenu */
    .highlight-good { color: $success; text-style: bold; }
    .highlight-warn { color: $warning; text-style: bold; }
    .highlight-bad { color: $error; text-style: bold; }
    .highlight-info { color: $primary; text-style: bold; }
    """

    # Variable pour stocker les infos de mise à jour
    update_info = None
    
    def compose(self) -> ComposeResult:
        # Format de date français
        import locale
        try:
            locale.setlocale(locale.LC_TIME, 'fr_FR.UTF-8')
        except Exception:
            try:
                locale.setlocale(locale.LC_TIME, 'French')
            except Exception:
                pass
        
        jours_fr = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]
        mois_fr = ["janvier", "février", "mars", "avril", "mai", "juin",
                   "juillet", "août", "septembre", "octobre", "novembre", "décembre"]
        now = datetime.now()
        date_str = f"📅 {jours_fr[now.weekday()]} {now.day} {mois_fr[now.month-1]} {now.year}"
        
        yield Header(show_clock=True)
        
        # Barre de mise à jour (masquée par défaut)
        with Horizontal(id="update-bar"):
            yield Static("🔄 Nouvelle version disponible !", id="update-text")
            yield Button("📥 Télécharger", id="btn-download-update")
            yield Button("✕", id="btn-dismiss-update")
        
        with Horizontal(id="welcome-bar"):
            yield Static("👋 Bienvenue !", id="welcome-text")
            yield Static(f"{date_str}  •  v{APP_VERSION}", id="welcome-date")
            yield Button("⚙️ Paramètres", id="btn-settings-header")
        
        with Grid(id="dashboard-grid"):
            yield DashboardCard("Emploi du temps", "📅", "btn-edt", "blue", id="card-edt")
            yield DashboardCard("Notes & Moyennes", "📝", "btn-notes", "green", id="card-notes")
            yield DashboardCard("Devoirs", "📚", "btn-devoirs", "orange", id="card-devoirs")
            yield DashboardCard("Cantine", "🍽️", "btn-cantine", "purple", id="card-cantine")
            yield DashboardCard("Compétences", "🎯", "btn-competences", "cyan", id="card-competences")
            yield DashboardCard("Infos & Comm.", "📢", "btn-infos", "red", id="card-infos")
        
        yield Footer()

    def on_mount(self) -> None:
        self._load_dashboard()
        self._check_updates()

    @work(thread=True)
    def _check_updates(self) -> None:
        """Vérifie les mises à jour en arrière-plan."""
        info = check_for_update()
        if info.get("update_available"):
            self.update_info = info
            self.app.call_from_thread(self._show_update_banner)
    
    def _show_update_banner(self) -> None:
        """Affiche la bannière de mise à jour."""
        try:
            update_bar = self.query_one("#update-bar")
            update_bar.add_class("visible")
            
            if self.update_info:
                version = self.update_info.get("latest_version", "?")
                text = self.query_one("#update-text", Static)
                text.update(f"🔄 Nouvelle version {version} disponible !")
        except Exception:
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        screens = {
            "btn-edt": "edt",
            "btn-notes": "notes",
            "btn-devoirs": "devoirs",
            "btn-cantine": "cantine",
            "btn-competences": "competences",
            "btn-infos": "infos",
            "btn-settings-header": "settings",
        }
        if event.button.id in screens:
            self.app.push_screen(screens[event.button.id])
        elif event.button.id == "btn-download-update":
            # Ouvrir la page de téléchargement
            if self.update_info:
                url = self.update_info.get("download_url", DOWNLOAD_URL)
                if open_download_page(url):
                    self.notify("🌐 Ouverture du navigateur...")
                else:
                    self.notify("❌ Impossible d'ouvrir le navigateur", severity="error")
        elif event.button.id == "btn-dismiss-update":
            # Masquer la bannière
            try:
                self.query_one("#update-bar").remove_class("visible")
            except Exception:
                pass

    @work(thread=True)
    def _load_dashboard(self) -> None:
        c = self.app.client
        
        try:
            name = c.info.name
            self.app.call_from_thread(
                lambda: self.query_one("#welcome-text", Static).update(f"👋 Bienvenue, {name} !")
            )
        except Exception:
            pass
        
        self.app.call_from_thread(self._load_edt_summary)
        self.app.call_from_thread(self._load_notes_summary)
        self.app.call_from_thread(self._load_devoirs_summary)
        self.app.call_from_thread(self._load_cantine_summary)
        self.app.call_from_thread(self._load_competences_summary)
        self.app.call_from_thread(self._load_infos_summary)
        self.app.call_from_thread(self._check_changes)

    def _load_edt_summary(self) -> None:
        content = self.query_one("#content-btn-edt", Static)
        c = self.app.client
        
        try:
            today = date.today()
            lessons = c.lessons(today)
            
            if not lessons:
                content.update("📭 Pas de cours aujourd'hui\n\n🎉 Profite de ta journée !")
                return
            
            active = [l for l in lessons if not l.canceled]
            canceled = [l for l in lessons if l.canceled]
            
            text = f"📚 [bold cyan]{len(active)}[/] cours aujourd'hui\n"
            if canceled:
                text += f"❌ [bold red]{len(canceled)}[/] annulé(s)\n"
            text += "\n"
            
            now = datetime.now()
            upcoming = [l for l in active if l.start > now]
            if upcoming:
                next_l = min(upcoming, key=lambda x: x.start)
                subj = next_l.subject.name if next_l.subject else "?"
                time = next_l.start.strftime("%H:%M")
                text += f"⏰ Prochain:\n[bold green]{subj}[/] à {time}"
            else:
                text += "✅ [bold green]Journée terminée ![/]"
            
            content.update(text)
            
        except Exception as e:
            content.update(f"[red]❌ Erreur: {str(e)[:25]}[/]")

    def _load_notes_summary(self) -> None:
        content = self.query_one("#content-btn-notes", Static)
        c = self.app.client
        
        try:
            avg = None
            period_name = ""
            # Priorité 1 : période courante
            try:
                if c.current_period and hasattr(c.current_period, 'overall_average') and c.current_period.overall_average:
                    avg = c.current_period.overall_average
                    period_name = c.current_period.name if c.current_period.name else ""
            except Exception:
                pass

            # Fallback : première période avec une moyenne
            if not avg:
                for p in c.periods:
                    if hasattr(p, 'overall_average') and p.overall_average:
                        avg = p.overall_average
                        period_name = p.name if p.name else ""
                        break
            
            text = ""
            if avg:
                try:
                    avg_num = float(str(avg).replace(",", "."))
                    if avg_num >= 14:
                        color = "green"
                    elif avg_num >= 10:
                        color = "yellow"
                    else:
                        color = "red"
                    text += f"📊 Moyenne: [bold {color}]{avg}[/]\n"
                    if period_name:
                        text += f"[dim]({period_name})[/]\n"
                    text += "\n"
                except ValueError:
                    text += f"📊 Moyenne: [bold]{avg}[/]\n"
                    if period_name:
                        text += f"[dim]({period_name})[/]\n"
                    text += "\n"
            
            grades = []
            try:
                if c.current_period and hasattr(c.current_period, 'grades'):
                    grades = list(c.current_period.grades)
            except Exception:
                pass
            
            if grades:
                recent = sorted(grades, key=lambda x: x.date if x.date else date.min, reverse=True)[:3]
                text += "📝 Dernières notes:\n"
                for g in recent:
                    subj = g.subject.name[:10] if g.subject else "?"
                    val = g.grade if g.grade else "?"
                    out = g.out_of if g.out_of else "20"
                    try:
                        pct = float(str(val).replace(",",".")) / float(str(out).replace(",","."))
                        color = "green" if pct >= 0.7 else "yellow" if pct >= 0.5 else "red"
                    except (ValueError, ZeroDivisionError):
                        color = "white"
                    text += f"  • {subj}: [{color}]{val}/{out}[/]\n"
            else:
                text += "Aucune note récente"
            
            content.update(text)
            
        except Exception as e:
            content.update(f"[red]❌ Erreur: {str(e)[:25]}[/]")

    def _load_devoirs_summary(self) -> None:
        content = self.query_one("#content-btn-devoirs", Static)
        c = self.app.client
        
        try:
            today = date.today()
            homework = c.homework(today, today + timedelta(days=14))
            
            if not homework:
                content.update("🎉 [bold green]Aucun devoir ![/]\n\n😎 Relax, tu es à jour")
                return
            
            pending = [h for h in homework if not (hasattr(h, 'done') and h.done)]
            done = [h for h in homework if hasattr(h, 'done') and h.done]
            
            text = f"📝 [bold orange]{len(pending)}[/] devoir(s) à faire\n"
            text += f"✅ [bold green]{len(done)}[/] terminé(s)\n\n"
            
            if pending:
                upcoming = sorted(pending, key=lambda x: x.date if x.date else date.max)[:2]
                text += "⏰ Prochains:\n"
                for h in upcoming:
                    subj = h.subject.name[:12] if h.subject else "?"
                    dt = h.date.strftime("%d/%m") if h.date else "?"
                    days_left = (h.date - today).days if h.date else 99
                    if days_left <= 1:
                        color = "red"
                    elif days_left <= 3:
                        color = "yellow"
                    else:
                        color = "white"
                    text += f"  • [{color}]{subj} ({dt})[/]\n"
            
            content.update(text)
            
        except Exception as e:
            content.update(f"[red]❌ Erreur: {str(e)[:25]}[/]")

    def _load_cantine_summary(self) -> None:
        content = self.query_one("#content-btn-cantine", Static)
        c = self.app.client
        try:
            today = date.today()
            menus = c.menus(today, today + timedelta(days=7))
            if menus:
                text = f"🍽️ [bold]{len(menus)}[/] menu(s) cette semaine\n\n"
                for m in menus[:2]:
                    d = m.date.strftime("%A %d/%m") if hasattr(m, 'date') and m.date else "?"
                    text += f"📅 [cyan]{d}[/]\n"
                    if hasattr(m, 'first_meal') and m.first_meal:
                        for item in m.first_meal[:2]:
                            name = item.name if hasattr(item, 'name') else str(item)
                            text += f"  • {name}\n"
                content.update(text.strip())
            else:
                content.update("📭 Aucun menu disponible")
        except Exception as e:
            content.update(f"[dim]🍽️ Menus non disponibles[/]")
    
    def _load_competences_summary(self) -> None:
        content = self.query_one("#content-btn-competences", Static)
        c = self.app.client
        try:
            evals = c.evaluations()
            if evals:
                acq = sum(1 for e in evals for a in (e.acquisitions if hasattr(e, 'acquisitions') else []) if hasattr(a, 'level') and a.level and "acquis" in str(a.level).lower() and "non" not in str(a.level).lower())
                non_acq = sum(1 for e in evals for a in (e.acquisitions if hasattr(e, 'acquisitions') else []) if hasattr(a, 'level') and a.level and "non acquis" in str(a.level).lower())
                text = f"🎯 [bold]{len(evals)}[/] évaluation(s)\n\n"
                text += f"[green]✅ {acq} acquis[/]\n"
                if non_acq:
                    text += f"[red]❌ {non_acq} non acquis[/]\n"
                content.update(text.strip())
            else:
                content.update("📭 Aucune évaluation")
        except Exception as e:
            content.update(f"[dim]🎯 Compétences non disponibles[/]")
    
    def _load_infos_summary(self) -> None:
        content = self.query_one("#content-btn-infos", Static)
        c = self.app.client
        try:
            infos = c.information_and_surveys()
            if infos:
                unread = sum(1 for i in infos if not i.read) if hasattr(infos[0], 'read') else 0
                text = f"📢 [bold]{len(infos)}[/] communication(s)\n\n"
                if unread:
                    text += f"[bold yellow]🔔 {unread} non lue(s)[/]\n"
                for i in infos[:2]:
                    title = i.title[:25] if hasattr(i, 'title') and i.title else "?"
                    text += f"  • {title}\n"
                content.update(text.strip())
            else:
                content.update("📭 Aucune communication")
        except Exception as e:
            content.update(f"[dim]📢 Communications non disponibles[/]")
    
    def _check_changes(self) -> None:
        """Vérifie les changements depuis le dernier lancement (notifications)."""
        c = self.app.client
        try:
            cache = load_cache()
            new_cache = {}
            changes = []
            
            # Comparer les notes
            try:
                grades = list(c.current_period.grades) if c.current_period else []
                new_grade_ids = set()
                for g in grades:
                    gid = f"{g.subject.name if g.subject else '?'}_{g.grade}_{g.date}" if hasattr(g, 'date') else f"{g.subject.name if g.subject else '?'}_{g.grade}"
                    new_grade_ids.add(gid)
                old_grade_ids = set(cache.get("grade_ids", []))
                new_ones = new_grade_ids - old_grade_ids
                if new_ones and old_grade_ids:
                    changes.append(f"📝 {len(new_ones)} nouvelle(s) note(s)")
                new_cache["grade_ids"] = list(new_grade_ids)
            except Exception:
                new_cache["grade_ids"] = cache.get("grade_ids", [])
            
            # Comparer les devoirs
            try:
                today = date.today()
                homeworks = c.homework(today, today + timedelta(days=14))
                new_hw_count = len(homeworks)
                old_hw_count = cache.get("homework_count", 0)
                if new_hw_count > old_hw_count and old_hw_count > 0:
                    changes.append(f"📚 {new_hw_count - old_hw_count} nouveau(x) devoir(s)")
                new_cache["homework_count"] = new_hw_count
            except Exception:
                new_cache["homework_count"] = cache.get("homework_count", 0)
            
            save_cache(new_cache)
            
            if changes:
                msg = " │ ".join(changes)
                self.app.call_from_thread(lambda: self.notify(f"🔔 {msg}", timeout=8))
        except Exception:
            pass

    def action_refresh(self) -> None:
        self._load_dashboard()
        self.notify("🔄 Actualisation...")

    def action_logout(self) -> None:
        self.app.client = None
        self.app.pop_screen()
        self.notify("👋 Déconnecté")
    
    def action_settings(self) -> None:
        """Ouvre la page des paramètres"""
        self.app.push_screen("settings")


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRANS DÉTAILLÉS
# ═══════════════════════════════════════════════════════════════════════════════

class DetailScreen(Screen):
    """Base pour écrans détaillés"""
    
    BINDINGS = [
        Binding("escape", "back", "← Retour"),
        Binding("r", "refresh", "Actualiser"),
    ]

    CSS = """
    DetailScreen { layout: vertical; background: $surface; }
    
    #detail-header {
        height: 4;
        padding: 1 2;
        content-align: center middle;
    }
    
    .header-blue { background: $primary; }
    .header-green { background: $success; }
    .header-orange { background: $warning; }
    .header-red { background: $error; }
    .header-purple { background: #7c3aed; }
    .header-cyan { background: #0891b2; }
    
    #detail-title { text-style: bold; color: $text; }
    
    #period-bar {
        height: 5;
        min-height: 5;
        background: $surface-darken-1;
        padding: 1;
        align: left middle;
    }
    
    #period-bar Button {
        margin: 0 1;
        min-width: 12;
        background: $success;
    }
    
    #period-bar Button:hover {
        background: $success-darken-1;
    }
    
    #period-label {
        width: auto;
        padding: 0 1;
        text-style: bold;
        content-align: center middle;
    }
    
    #week-nav {
        height: 5;
        min-height: 5;
        background: $surface-darken-1;
        padding: 1;
        align: center middle;
    }
    
    #week-nav Button {
        margin: 0 1;
        min-width: 14;
    }
    
    #week-nav #btn-prev-week {
        background: $primary;
    }
    
    #week-nav #btn-next-week {
        background: $primary;
    }
    
    #week-nav #btn-today {
        background: $success;
    }
    
    #week-label {
        width: auto;
        min-width: 40;
        padding: 0 2;
        text-style: bold;
        text-align: center;
        content-align: center middle;
        color: $text;
        height: auto;
    }
    
    #detail-content { height: 1fr; padding: 1 2; }
    
    /* Items */
    .day-header {
        background: $primary-darken-1; 
        padding: 0 1;
        text-style: bold; 
        margin-top: 1;
        color: $text;
    }
    .day-today { background: $success; }
    
    .item { 
        padding: 1; 
        background: $panel; 
        border-left: thick $primary; 
        margin-bottom: 1;
    }
    .item-canceled { border-left: thick $error; background: $error 15%; }
    .item-done { border-left: thick $success; background: $success 15%; }
    .item-warning { border-left: thick $warning; background: $warning 15%; }
    .item-error { border-left: thick $error; background: $error 15%; }
    .item-good { border-left: thick $success; }
    .item-medium { border-left: thick $warning; }
    .item-bad { border-left: thick $error; }
    
    .section { 
        background: $primary; 
        padding: 0 1; 
        text-style: bold; 
        margin: 1 0;
        color: $text;
    }
    .section-green { background: $success; }
    .section-orange { background: $warning; }
    .section-red { background: $error; }
    
    .empty { text-align: center; color: $text-muted; padding: 2; }
    .error { color: $error; padding: 1; }

    /* EDT DataTable */
    #edt-table {
        height: 1fr;
        margin: 0 1;
    }
    #edt-table > .datatable--header {
        background: $primary-darken-1;
        color: $text;
        text-style: bold;
    }

    /* Bouton simulateur */
    #btn-sim-open {
        dock: right;
        background: $accent;
    }

    /* Boutons communications */
    .info-btn {
        width: 100%;
        height: auto;
        min-height: 4;
        background: $panel;
        border-left: thick $primary;
        margin-bottom: 1;
        text-align: left;
        content-align: left middle;
        padding: 1;
    }
    .info-btn:hover {
        background: $primary 20%;
        border-left: thick $accent;
    }
    """

    def action_back(self) -> None:
        self.app.pop_screen()

    def action_refresh(self) -> None:
        self.load_data()
        self.notify("🔄 Actualisation...")

    def load_data(self) -> None:
        pass


class EdtScreen(DetailScreen):
    """Emploi du temps avec navigation par semaine"""
    
    week_offset = 0  # 0 = semaine actuelle, -1 = semaine précédente, +1 = semaine suivante

    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="detail-header", classes="header-blue"):
            yield Static("📅 EMPLOI DU TEMPS", id="detail-title")
        with Horizontal(id="week-nav"):
            yield Button("◀ Précédent", id="btn-prev-week", variant="default")
            yield Static("Semaine du ...", id="week-label")
            yield Button("Aujourd'hui", id="btn-today", variant="primary")
            yield Button("Suivant ▶", id="btn-next-week", variant="default")
        yield DataTable(id="edt-table", zebra_stripes=True)
        yield ScrollableContainer(id="detail-content")
        yield Footer()

    def on_mount(self) -> None:
        self.week_offset = 0
        # Afficher le bon widget selon la config
        config = load_config()
        edt_view = config.get("edt_view", "table")
        table = self.query_one("#edt-table", DataTable)
        scroll = self.query_one("#detail-content", ScrollableContainer)
        if edt_view == "list":
            table.display = False
            scroll.display = True
        else:
            table.display = True
            scroll.display = False
        self.load_data()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id
        if btn_id == "btn-prev-week":
            self.week_offset -= 1
            self.load_data()
        elif btn_id == "btn-next-week":
            self.week_offset += 1
            self.load_data()
        elif btn_id == "btn-today":
            self.week_offset = 0
            self.load_data()

    @work(thread=True)
    def load_data(self) -> None:
        self.app.call_from_thread(self._load)

    def _load(self) -> None:
        config = load_config()
        edt_view = config.get("edt_view", "table")
        
        c = self.app.client
        
        try:
            today = date.today()
            base_date = today + timedelta(weeks=self.week_offset)
            start = base_date - timedelta(days=base_date.weekday())
            end = start + timedelta(days=6)
            
            week_label = self.query_one("#week-label", Static)
            if self.week_offset == 0:
                week_label.update(f"📅 Semaine du {start.strftime('%d/%m')} au {end.strftime('%d/%m')} (actuelle)")
            else:
                week_label.update(f"📅 Semaine du {start.strftime('%d/%m')} au {end.strftime('%d/%m')}")
            
            lessons = c.lessons(start, end)
            
            # Organiser par jour
            days = {}
            names = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]
            
            for l in lessons:
                d = l.start.date()
                if d not in days:
                    days[d] = []
                days[d].append(l)
            
            now = datetime.now()
            
            if edt_view == "list":
                self._load_list_view(days, names, today, now, lessons)
            else:
                self._load_table_view(days, names, today, now, lessons)
            
            # Compteur d'heures de la semaine
            active_lessons = [l for l in lessons if not l.canceled]
            total_min = sum(int((l.end - l.start).total_seconds() / 60) for l in active_lessons)
            h, m = divmod(total_min, 60)
            
            week_label = self.query_one("#week-label", Static)
            current_text = str(week_label.renderable) if hasattr(week_label, 'renderable') else ""
            week_label.update(f"{current_text}\n⏱️ {len(active_lessons)} cours │ {h}h{m:02d} total")
            
            # Temps restant aujourd'hui
            today_lessons = [l for l in active_lessons if l.start.date() == today and l.end > now]
            if today_lessons:
                last = max(today_lessons, key=lambda x: x.end)
                rem_min = int((last.end - now).total_seconds() / 60)
                if rem_min > 0:
                    rh, rm = divmod(rem_min, 60)
                    week_label.update(f"{current_text}\n⏱️ {len(active_lessons)} cours │ {h}h{m:02d} │ Fin dans {rh}h{rm:02d}")
                    
        except Exception as e:
            if edt_view == "list":
                scroll = self.query_one("#detail-content", ScrollableContainer)
                scroll.mount(Static(f"[red]❌ Erreur: {e}[/]", classes="error"))
            else:
                table = self.query_one("#edt-table", DataTable)
                table.clear(columns=True)
                table.add_column("Erreur", key="err")
                table.add_row(Text(f"❌ Erreur: {e}", style="bold red"))
    
    def _load_table_view(self, days, names, today, now, lessons) -> None:
        """Vue tableau DataTable"""
        table = self.query_one("#edt-table", DataTable)
        table.clear(columns=True)
        
        table.add_column("Jour", width=16, key="jour")
        table.add_column("Horaire", width=16, key="horaire")
        table.add_column("Matière", width=22, key="matiere")
        table.add_column("Salle", width=10, key="salle")
        table.add_column("Professeur", width=20, key="prof")
        table.add_column("Statut", width=14, key="statut")
        
        if not lessons:
            table.add_row(
                Text(""), Text(""),
                Text("📭 Aucun cours cette semaine", style="dim italic"),
                Text(""), Text(""), Text("")
            )
            return
        
        for d in sorted(days.keys()):
            is_today = d == today
            day_name = names[d.weekday()]
            day_str = f"{day_name} {d.strftime('%d/%m')}"
            
            if is_today:
                day_text = Text(f"📍 {day_str}", style="bold green")
            else:
                day_text = Text(f"  {day_str}", style="bold cyan")
            
            empty = Text("")
            table.add_row(day_text, empty, empty, empty, empty, empty)
            
            sorted_lessons = sorted(days[d], key=lambda x: x.start)
            prev_end = None
            for l in sorted_lessons:
                if prev_end is not None and l.start > prev_end:
                    pause_min = int((l.start - prev_end).total_seconds() / 60)
                    if pause_min >= 5:
                        pause_str = f"{prev_end.strftime('%H:%M')} → {l.start.strftime('%H:%M')}"
                        h, m = divmod(pause_min, 60)
                        dur = f"{h}h{m:02d}" if h > 0 else f"0h{m:02d}"
                        table.add_row(
                            Text(""),
                            Text(pause_str, style="dim italic"),
                            Text(f"Pause ({dur})", style="dim italic"),
                            Text(""), Text(""), Text("")
                        )
                
                time_str = f"{l.start.strftime('%H:%M')} → {l.end.strftime('%H:%M')}"
                subj = l.subject.name if l.subject else "?"
                room = l.classroom if l.classroom else ""
                teacher = l.teacher_name if l.teacher_name else ""
                is_current = (d == today and l.start <= now <= l.end)
                
                if l.canceled:
                    time_text = Text(time_str, style="red strike")
                    subj_text = Text(f"❌ {subj}", style="red strike")
                    room_text = Text(room, style="dim red")
                    prof_text = Text(teacher, style="dim red")
                    status_text = Text("ANNULÉ", style="bold red")
                elif is_current:
                    time_text = Text(f"▶ {time_str}", style="bold green")
                    subj_text = Text(subj, style="bold green")
                    room_text = Text(room, style="green")
                    prof_text = Text(teacher, style="green")
                    status_text = Text("EN COURS", style="bold green")
                elif l.status:
                    time_text = Text(time_str, style="yellow")
                    subj_text = Text(subj, style="bold yellow")
                    room_text = Text(room, style="yellow")
                    prof_text = Text(teacher, style="yellow")
                    status_text = Text(f"⚠️ {l.status}", style="bold yellow")
                else:
                    time_text = Text(time_str, style="cyan")
                    subj_text = Text(subj, style="bold white")
                    room_text = Text(room, style="dim")
                    prof_text = Text(teacher, style="dim")
                    status_text = Text("─", style="dim")
                
                table.add_row(Text(""), time_text, subj_text, room_text, prof_text, status_text)
                prev_end = l.end
    
    def _load_list_view(self, days, names, today, now, lessons) -> None:
        """Vue liste (ancienne version)"""
        scroll = self.query_one("#detail-content", ScrollableContainer)
        for child in list(scroll.children):
            child.remove()
        
        if not lessons:
            scroll.mount(Static("📭 Aucun cours cette semaine", classes="empty"))
            return
        
        for d in sorted(days.keys()):
            is_today = d == today
            cls = "day-header day-today" if is_today else "day-header"
            marker = "📍 " if is_today else ""
            scroll.mount(Static(f"{marker}{names[d.weekday()]} {d.strftime('%d/%m')}", classes=cls))
            
            sorted_lessons = sorted(days[d], key=lambda x: x.start)
            prev_end = None
            for l in sorted_lessons:
                # Pause
                if prev_end is not None and l.start > prev_end:
                    pause_min = int((l.start - prev_end).total_seconds() / 60)
                    if pause_min >= 5:
                        h, m = divmod(pause_min, 60)
                        dur = f"{h}h{m:02d}" if h > 0 else f"0h{m:02d}"
                        scroll.mount(Static(
                            f"[dim italic]  {prev_end.strftime('%H:%M')} → {l.start.strftime('%H:%M')} │ Pause ({dur})[/]",
                            classes="item"
                        ))
                
                time_str = f"{l.start.strftime('%H:%M')} → {l.end.strftime('%H:%M')}"
                subj = l.subject.name if l.subject else "?"
                room = l.classroom if l.classroom else ""
                teacher = l.teacher_name if l.teacher_name else ""
                is_current = (d == today and l.start <= now <= l.end)
                
                if l.canceled:
                    text = f"[red]❌ {time_str}[/]\n"
                    text += f"[red strike]{subj}[/] [dim red]ANNULÉ[/]"
                    if room:
                        text += f"\n[dim]🚪 {room}[/]"
                    item_cls = "item item-canceled"
                elif is_current:
                    text = f"[bold green]▶ {time_str}[/]\n"
                    text += f"[bold green]{subj}[/]"
                    if room:
                        text += f"\n[green]🚪 {room}[/]"
                    if teacher:
                        text += f" [green]│ 👨‍🏫 {teacher}[/]"
                    item_cls = "item item-done"
                else:
                    text = f"[bold cyan]⏰ {time_str}[/]\n"
                    text += f"[bold]📚 {subj}[/]"
                    if room:
                        text += f"\n[dim]🚪 {room}[/]"
                    if teacher:
                        text += f" [dim]│ 👨‍🏫 {teacher}[/]"
                    if l.status:
                        text += f"\n[bold yellow]⚠️ {l.status}[/]"
                        item_cls = "item item-warning"
                    else:
                        item_cls = "item"
                
                scroll.mount(Static(text, classes=item_cls))
                prev_end = l.end


class NotesScreen(DetailScreen):
    """Notes avec sélection de période"""
    
    selected_period_idx = 0
    filtered_periods = []

    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="detail-header", classes="header-green"):
            yield Static("📝 NOTES & MOYENNES", id="detail-title")
        with Horizontal(id="period-bar"):
            yield Static("📆 Période: ", id="period-label")
            yield Button("P1", id="btn-p1", variant="primary")
            yield Button("P2", id="btn-p2", variant="default")
            yield Button("P3", id="btn-p3", variant="default")
            yield Button("🧮 Simuler", id="btn-sim-open")
        
        yield ScrollableContainer(id="detail-content")
        yield Footer()

    def on_mount(self) -> None:
        self.selected_period_idx = 0
        self._init_periods()
        self._setup_buttons()
        self.load_data()

    def _setup_buttons(self) -> None:
        """Configure les boutons selon la config"""
        config = self.app.config
        period_type = config.get("period_type", "trimestre")
        
        btn1 = self.query_one("#btn-p1", Button)
        btn2 = self.query_one("#btn-p2", Button)
        btn3 = self.query_one("#btn-p3", Button)
        
        if period_type == "semestre":
            btn1.label = "Semestre 1"
            btn2.label = "Semestre 2"
            btn3.display = False
        else:
            btn1.label = "Trimestre 1"
            btn2.label = "Trimestre 2"
            btn3.label = "Trimestre 3"
            btn3.display = True
        
        # Mettre à jour avec les vrais noms si disponibles
        self._update_buttons()

    def _init_periods(self) -> None:
        """Initialise les périodes filtrées"""
        c = self.app.client
        config = self.app.config
        period_type = config.get("period_type", "trimestre")
        
        # Filtrer les périodes selon le type configuré
        filtered_periods = []
        for i, p in enumerate(c.periods):
            name = p.name.lower() if p.name else ""
            if period_type == "trimestre" and ("trimestre" in name or "t1" in name or "t2" in name or "t3" in name):
                filtered_periods.append((i, p))
            elif period_type == "semestre" and ("semestre" in name or "s1" in name or "s2" in name):
                filtered_periods.append((i, p))
        
        # Si aucune période filtrée, prendre toutes les périodes
        if not filtered_periods:
            filtered_periods = [(i, p) for i, p in enumerate(c.periods)]
        
        self.filtered_periods = filtered_periods

    def _update_buttons(self) -> None:
        """Met à jour le texte et la visibilité des boutons"""
        config = self.app.config
        period_type = config.get("period_type", "trimestre")
        
        btns = [self.query_one("#btn-p1", Button), self.query_one("#btn-p2", Button)]
        
        # Ajouter le 3ème bouton seulement si trimestre
        try:
            btn3 = self.query_one("#btn-p3", Button)
            btns.append(btn3)
        except Exception:
            pass
        
        for i, btn in enumerate(btns):
            if i < len(self.filtered_periods):
                _, period = self.filtered_periods[i]
                name = period.name if period.name else f"Période {i+1}"
                btn.label = name[:15]
                btn.display = True
                btn.variant = "primary" if i == self.selected_period_idx else "default"
            else:
                btn.display = False

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_map = {"btn-p1": 0, "btn-p2": 1, "btn-p3": 2}
        if event.button.id in btn_map:
            self.selected_period_idx = btn_map[event.button.id]
            self._update_buttons()
            self._load_period_data()
        elif event.button.id == "btn-sim-open":
            self.app.push_screen("simulator")
    
    @work(thread=True)
    def load_data(self) -> None:
        self.app.call_from_thread(self._load_period_data)

    def _load_period_data(self) -> None:
        """Charge les données de la période sélectionnée"""
        scroll = self.query_one("#detail-content", ScrollableContainer)
        for child in list(scroll.children):
            child.remove()
        
        c = self.app.client
        
        try:
            if not hasattr(self, 'filtered_periods') or not self.filtered_periods:
                scroll.mount(Static("Aucune période disponible", classes="empty"))
                return
            
            # Récupérer la période sélectionnée
            real_idx, period = self.filtered_periods[self.selected_period_idx]
            
            period_name = period.name if period.name else "Période"
            period_start = period.start.strftime("%d/%m/%Y") if period.start else ""
            period_end = period.end.strftime("%d/%m/%Y") if period.end else ""
            
            # En-tête de la période
            scroll.mount(Static(
                f"📆 {period_name}\n   Du {period_start} au {period_end}",
                classes="section"
            ))
            
            # Moyenne générale de la période
            try:
                if hasattr(period, 'overall_average') and period.overall_average:
                    avg = period.overall_average
                    class_avg = period.class_overall_average if hasattr(period, 'class_overall_average') else "?"
                    
                    try:
                        avg_num = float(str(avg).replace(",", "."))
                        if avg_num >= 14:
                            color = "green"
                        elif avg_num >= 10:
                            color = "yellow"
                        else:
                            color = "red"
                    except ValueError:
                        color = "white"
                    
                    text = f"[bold]📊 MOYENNE GÉNÉRALE[/]\n"
                    text += f"   Toi: [bold {color}]{avg}[/] │ Classe: {class_avg}"
                    scroll.mount(Static(text, classes="item"))
            except Exception:
                pass
            
            # Moyennes par matière
            scroll.mount(Static("📚 Moyennes par matière", classes="section section-green"))
            
            has_avg = False
            try:
                if hasattr(period, 'averages') and period.averages:
                    for a in period.averages:
                        has_avg = True
                        subj = a.subject.name if a.subject else "?"
                        stu = a.student if a.student else "?"
                        cls_avg = a.class_average if a.class_average else "?"
                        out = a.out_of if a.out_of else "20"
                        
                        try:
                            pct = float(str(stu).replace(",",".")) / float(str(out).replace(",","."))
                            if pct >= 0.7:
                                color, item_cls = "green", "item item-good"
                            elif pct >= 0.5:
                                color, item_cls = "yellow", "item item-medium"
                            else:
                                color, item_cls = "red", "item item-bad"
                        except (ValueError, ZeroDivisionError):
                            color, item_cls = "white", "item"
                        
                        text = f"[bold]📖 {subj}[/]\n"
                        text += f"   Toi: [bold {color}]{stu}/{out}[/] │ Classe: {cls_avg}"
                        scroll.mount(Static(text, classes=item_cls))
            except Exception:
                pass
            
            if not has_avg:
                scroll.mount(Static("Aucune moyenne pour cette période", classes="empty"))
            
            
            # Grades list pour la suite
            grades = []
            try:
                if hasattr(period, 'grades') and period.grades:
                    grades = list(period.grades)
            except Exception:
                pass
            
            # Graphique en barres des moyennes par matière
            if hasattr(period, 'averages') and period.averages:
                subj_avgs = {}
                for a in period.averages:
                    subj_name = a.subject.name if a.subject else "?"
                    stu_val = str(a.student) if a.student else "0"
                    out_val = str(a.out_of) if a.out_of else "20"
                    try:
                        avg_20 = float(stu_val.replace(",", ".")) / float(out_val.replace(",", ".")) * 20
                        subj_avgs[subj_name] = avg_20
                    except (ValueError, ZeroDivisionError):
                        pass
                if subj_avgs:
                    chart = bar_chart(subj_avgs)
                    scroll.mount(Static(
                        f"📊 Graphique des moyennes:\n{chart}",
                        classes="item"
                    ))
            
            # Notes de la période
            scroll.mount(Static("📝 Notes de la période", classes="section section-green"))
            
            if not grades:
                scroll.mount(Static("Aucune note pour cette période", classes="empty"))
            else:
                for g in sorted(grades, key=lambda x: x.date if x.date else date.min, reverse=True):
                    subj = g.subject.name if g.subject else "?"
                    val = g.grade if g.grade else "?"
                    out = g.out_of if g.out_of else "20"
                    coef = g.coefficient if g.coefficient else "1"
                    dt = g.date.strftime("%d/%m/%Y") if g.date else "?"
                    comment = g.comment if hasattr(g, 'comment') and g.comment else ""
                    g_avg = str(g.average) if hasattr(g, 'average') and g.average else ""
                    g_min = str(g.min) if hasattr(g, 'min') and g.min else ""
                    g_max = str(g.max) if hasattr(g, 'max') and g.max else ""
                    
                    try:
                        pct = float(str(val).replace(",",".")) / float(str(out).replace(",","."))
                        if pct >= 0.7:
                            color, item_cls = "green", "item item-good"
                        elif pct >= 0.5:
                            color, item_cls = "yellow", "item item-medium"
                        else:
                            color, item_cls = "red", "item item-bad"
                    except (ValueError, ZeroDivisionError):
                        color, item_cls = "white", "item"
                    
                    text = f"[bold]📖 {subj}[/]\n"
                    text += f"   [bold {color}]{val}/{out}[/] (coef {coef}) │ {dt}"
                    
                    # Min / Max / Classe
                    if g_avg or g_min or g_max:
                        text += "\n   "
                        if g_avg:
                            text += f"Classe: [cyan]{g_avg}[/] "
                        if g_min:
                            text += f"│ Min: [red]{g_min}[/] "
                        if g_max:
                            text += f"│ Max: [green]{g_max}[/]"
                    
                    if comment:
                        text += f"\n   [dim]💬 {comment[:50]}[/]"
                    
                    scroll.mount(Static(text, classes=item_cls))
                    
        except Exception as e:
            scroll.mount(Static(f"[red]❌ Erreur: {e}[/]", classes="error"))


class DevoirsScreen(DetailScreen):
    """Devoirs"""

    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="detail-header", classes="header-orange"):
            yield Static("📚 DEVOIRS", id="detail-title")
        yield ScrollableContainer(id="detail-content")
        yield Footer()

    def on_mount(self) -> None:
        self.load_data()

    @work(thread=True)
    def load_data(self) -> None:
        self.app.call_from_thread(self._load)

    def _load(self) -> None:
        scroll = self.query_one("#detail-content", ScrollableContainer)
        for child in list(scroll.children):
            child.remove()
        
        c = self.app.client
        
        try:
            today = date.today()
            homework = c.homework(today, today + timedelta(days=60))
            
            if not homework:
                scroll.mount(Static("🎉 Aucun devoir à venir !", classes="empty"))
                return
            
            pending = [h for h in homework if not (hasattr(h, 'done') and h.done)]
            done_list = [h for h in homework if hasattr(h, 'done') and h.done]
            
            if pending:
                scroll.mount(Static(f"📝 À FAIRE ({len(pending)})", classes="section section-orange"))
                for h in sorted(pending, key=lambda x: x.date if x.date else date.max):
                    subj = h.subject.name if h.subject else "?"
                    dt = h.date.strftime("%A %d/%m") if h.date else "?"
                    desc = h.description if h.description else "Pas de description"
                    days_left = (h.date - today).days if h.date else 99
                    
                    if days_left <= 1:
                        urgency = "[bold red]⚠️ URGENT[/]"
                        item_cls = "item item-error"
                    elif days_left <= 3:
                        urgency = "[yellow]⏰ Bientôt[/]"
                        item_cls = "item item-warning"
                    else:
                        urgency = ""
                        item_cls = "item"
                    
                    text = f"[bold orange]📅 {dt}[/] {urgency}\n"
                    text += f"[bold]📖 {subj}[/]\n"
                    text += f"[dim]{desc[:150]}[/]"
                    scroll.mount(Static(text, classes=item_cls))
            
            if done_list:
                scroll.mount(Static(f"✅ TERMINÉS ({len(done_list)})", classes="section section-green"))
                for h in sorted(done_list, key=lambda x: x.date if x.date else date.max)[:10]:
                    subj = h.subject.name if h.subject else "?"
                    dt = h.date.strftime("%d/%m") if h.date else "?"
                    
                    text = f"[green]✅ {subj}[/] ({dt})"
                    scroll.mount(Static(text, classes="item item-done"))
                    
        except Exception as e:
            scroll.mount(Static(f"[red]❌ Erreur: {e}[/]", classes="error"))


class VieScreen(DetailScreen):
    """Vie scolaire"""

    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="detail-header", classes="header-red"):
            yield Static("🚫 VIE SCOLAIRE", id="detail-title")
        yield ScrollableContainer(id="detail-content")
        yield Footer()

    def on_mount(self) -> None:
        self.load_data()

    @work(thread=True)
    def load_data(self) -> None:
        self.app.call_from_thread(self._load)

    def _load(self) -> None:
        scroll = self.query_one("#detail-content", ScrollableContainer)
        for child in list(scroll.children):
            child.remove()
        
        c = self.app.client
        
        try:
            scroll.mount(Static("🚫 ABSENCES", classes="section section-red"))
            
            has_abs = False
            for p in c.periods:
                try:
                    if hasattr(p, 'absences'):
                        for a in p.absences:
                            has_abs = True
                            if a.justified:
                                just = "[green]✅ Justifiée[/]"
                                item_cls = "item"
                            else:
                                just = "[red]❌ Non justifiée[/]"
                                item_cls = "item item-error"
                            
                            from_d = a.from_date.strftime("%d/%m/%Y %H:%M") if a.from_date else "?"
                            to_d = a.to_date.strftime("%H:%M") if a.to_date else "?"
                            reason = a.reasons[0] if a.reasons else "Pas de motif"
                            
                            text = f"[bold]📅 {from_d} → {to_d}[/]\n{just}\n[dim]📝 {reason}[/]"
                            scroll.mount(Static(text, classes=item_cls))
                except Exception:
                    pass
            
            if not has_abs:
                scroll.mount(Static("✨ Aucune absence !", classes="empty"))
            
            scroll.mount(Static("⏰ RETARDS", classes="section section-orange"))
            
            has_del = False
            for p in c.periods:
                try:
                    if hasattr(p, 'delays'):
                        for d in p.delays:
                            has_del = True
                            if d.justified:
                                just = "[green]✅ Justifié[/]"
                                item_cls = "item"
                            else:
                                just = "[yellow]❌ Non justifié[/]"
                                item_cls = "item item-warning"
                            
                            dt = d.date.strftime("%d/%m/%Y") if d.date else "?"
                            mins = f"{d.minutes} minutes" if hasattr(d, 'minutes') else "?"
                            reason = d.reasons[0] if d.reasons else "Pas de motif"
                            
                            text = f"[bold]📅 {dt} - {mins}[/]\n{just}\n[dim]📝 {reason}[/]"
                            scroll.mount(Static(text, classes=item_cls))
                except Exception:
                    pass
            
            if not has_del:
                scroll.mount(Static("✨ Aucun retard !", classes="empty"))
                
        except Exception as e:
            scroll.mount(Static(f"[red]❌ Erreur: {e}[/]", classes="error"))


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRAN CANTINE
# ═══════════════════════════════════════════════════════════════════════════════

class CantineScreen(DetailScreen):
    """Menus de la cantine"""

    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="detail-header", classes="header-purple"):
            yield Static("🍽️ MENUS DE LA CANTINE", id="detail-title")
        yield ScrollableContainer(id="detail-content")
        yield Footer()

    def on_mount(self) -> None:
        self.load_data()

    @work(thread=True)
    def load_data(self) -> None:
        self.app.call_from_thread(self._load)

    def _load(self) -> None:
        scroll = self.query_one("#detail-content", ScrollableContainer)
        for child in list(scroll.children):
            child.remove()
        
        c = self.app.client
        try:
            today = date.today()
            menus = c.menus(today, today + timedelta(days=14))
            
            if not menus:
                scroll.mount(Static("📭 Aucun menu disponible", classes="empty"))
                return
            
            for m in menus:
                d = m.date.strftime("%A %d/%m/%Y") if hasattr(m, 'date') and m.date else "?"
                scroll.mount(Static(f"📅 {d}", classes="day-header"))
                
                meals = []
                for attr in ['first_meal', 'lunch', 'name']:
                    if hasattr(m, attr):
                        val = getattr(m, attr)
                        if val and isinstance(val, list):
                            meals = val
                            break
                
                if meals:
                    text = ""
                    for item in meals:
                        name = item.name if hasattr(item, 'name') else str(item)
                        labels = ""
                        if hasattr(item, 'labels') and item.labels:
                            labels = " ".join([f"[dim]({l})[/]" for l in item.labels])
                        text += f"  🍴 {name} {labels}\n"
                    scroll.mount(Static(text.strip(), classes="item"))
                else:
                    # Essayer d'afficher les attributs disponibles
                    text = ""
                    for attr_name in dir(m):
                        if not attr_name.startswith('_') and attr_name != 'date':
                            val = getattr(m, attr_name, None)
                            if val and not callable(val):
                                text += f"  • {attr_name}: {val}\n"
                    if text:
                        scroll.mount(Static(text.strip(), classes="item"))
                    else:
                        scroll.mount(Static("[dim]  Aucun détail disponible[/]", classes="item"))
                        
        except Exception as e:
            scroll.mount(Static(f"[red]❌ Erreur: {e}[/]", classes="error"))


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRAN COMPÉTENCES
# ═══════════════════════════════════════════════════════════════════════════════

class CompetencesScreen(DetailScreen):
    """Compétences et évaluations"""

    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="detail-header", classes="header-cyan"):
            yield Static("🎯 COMPÉTENCES & ÉVALUATIONS", id="detail-title")
        yield ScrollableContainer(id="detail-content")
        yield Footer()

    def on_mount(self) -> None:
        self.load_data()

    @work(thread=True)
    def load_data(self) -> None:
        self.app.call_from_thread(self._load)

    def _load(self) -> None:
        scroll = self.query_one("#detail-content", ScrollableContainer)
        for child in list(scroll.children):
            child.remove()
        
        c = self.app.client
        try:
            evals = c.evaluations()
            
            if not evals:
                scroll.mount(Static("📭 Aucune évaluation", classes="empty"))
                return
            
            for ev in evals:
                subj = ev.subject.name if hasattr(ev, 'subject') and ev.subject else "?"
                d = ev.date.strftime("%d/%m/%Y") if hasattr(ev, 'date') and ev.date else ""
                teacher = ev.teacher if hasattr(ev, 'teacher') else ""
                name = ev.name if hasattr(ev, 'name') else ""
                
                header = f"📚 [bold]{subj}[/]"
                if name:
                    header += f" - {name}"
                if d:
                    header += f" [dim]({d})[/]"
                if teacher:
                    header += f" [dim]│ 👨‍🏫 {teacher}[/]"
                
                scroll.mount(Static(header, classes="section"))
                
                if hasattr(ev, 'acquisitions') and ev.acquisitions:
                    text = ""
                    for a in ev.acquisitions:
                        acq_name = a.name if hasattr(a, 'name') else "?"
                        level = str(a.level) if hasattr(a, 'level') and a.level else "?"
                        
                        level_lower = level.lower()
                        if "non" in level_lower and "acquis" in level_lower:
                            color = "red"
                            icon = "❌"
                        elif "en cours" in level_lower or "partiellement" in level_lower:
                            color = "yellow"
                            icon = "🔄"
                        elif "acquis" in level_lower:
                            color = "green"
                            icon = "✅"
                        else:
                            color = "white"
                            icon = "•"
                        
                        text += f"  {icon} [{color}]{acq_name}[/] → [{color}]{level}[/]\n"
                    
                    scroll.mount(Static(text.strip(), classes="item"))
                else:
                    scroll.mount(Static("[dim]  Aucune compétence détaillée[/]", classes="item"))
                    
        except Exception as e:
            scroll.mount(Static(f"[red]❌ Erreur: {e}[/]", classes="error"))


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRAN INFORMATIONS
# ═══════════════════════════════════════════════════════════════════════════════

class InfosScreen(DetailScreen):
    """Informations et communications"""

    _infos_list = []
    _all_infos = []
    _render_id = 0

    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="detail-header", classes="header-red"):
            yield Static("📢 INFORMATIONS & COMMUNICATIONS", id="detail-title")
        with Horizontal(id="period-bar"):
            yield Static("🔍 ", id="period-label")
            yield Input(placeholder="Rechercher une communication...", id="info-search")
        yield ScrollableContainer(id="detail-content")
        yield Footer()

    def on_mount(self) -> None:
        self._infos_list = []
        self._all_infos = []
        self.load_data()

    @work(thread=True)
    def load_data(self) -> None:
        self.app.call_from_thread(self._load)

    def _load(self) -> None:
        c = self.app.client
        try:
            infos = c.information_and_surveys()
            raw = list(infos) if infos else []
            
            # Trier par date décroissante (plus récente en premier)
            def sort_key(info):
                if hasattr(info, 'creation_date') and info.creation_date:
                    return info.creation_date
                return datetime.min
            
            self._all_infos = sorted(raw, key=sort_key, reverse=True)
            self._infos_list = list(self._all_infos)
            self._render_list()
            
        except Exception as e:
            scroll = self.query_one("#detail-content", ScrollableContainer)
            for child in list(scroll.children):
                child.remove()
            scroll.mount(Static(f"[red]❌ Erreur: {e}[/]", classes="error"))

    def on_input_changed(self, event: Input.Changed) -> None:
        """Filtre les communications en temps réel"""
        if event.input.id == "info-search":
            query = event.value.strip().lower()
            if not query:
                self._infos_list = list(self._all_infos)
            else:
                self._infos_list = [
                    info for info in self._all_infos
                    if query in (info.title or "").lower()
                    or query in (info.author or "").lower()
                    or query in (str(info.content) if hasattr(info, 'content') and info.content else "").lower()
                ]
            self._render_list()

    def _render_list(self) -> None:
        """Affiche la liste des communications (filtrée ou non)"""
        self._render_id += 1
        rid = self._render_id
        
        scroll = self.query_one("#detail-content", ScrollableContainer)
        scroll.remove_children()
        
        if not self._infos_list:
            scroll.mount(Static("📭 Aucune communication trouvée", classes="empty"))
            return
        
        scroll.mount(Static(f"[dim]{len(self._infos_list)} communication(s) — triées par date[/]", classes="empty"))
        
        for idx, info in enumerate(self._infos_list):
            title = info.title if hasattr(info, 'title') and info.title else "Sans titre"
            author = info.author if hasattr(info, 'author') and info.author else ""
            d = info.creation_date.strftime("%d/%m/%Y") if hasattr(info, 'creation_date') and info.creation_date else ""
            read_icon = "✅" if hasattr(info, 'read') and info.read else "🔔"
            
            preview = ""
            if hasattr(info, 'content') and info.content:
                preview = str(info.content)[:80].replace("\n", " ")
                if len(str(info.content)) > 80:
                    preview += "…"
            
            text = f"{read_icon} [bold]{title}[/]"
            if d:
                text += f"  [dim]({d})[/]"
            if author:
                text += f"  [dim]👤 {author}[/]"
            if preview:
                text += f"\n   [dim]{preview}[/]"
            text += "\n   [cyan][bold]→ Cliquer pour lire[/][/]"
            
            btn = Button(text, id=f"btn-info-{rid}-{idx}", classes="info-btn")
            scroll.mount(btn)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id.startswith("btn-info-"):
            try:
                # Format: btn-info-{render_id}-{idx}
                parts = btn_id.split("-")
                idx = int(parts[-1])
                if 0 <= idx < len(self._infos_list):
                    info = self._infos_list[idx]
                    self.app.push_screen(InfoDetailScreen(info))
            except (ValueError, IndexError):
                pass


class InfoDetailScreen(Screen):
    """Affichage complet d'une communication"""
    
    BINDINGS = [
        Binding("escape", "back", "← Retour"),
    ]
    
    CSS = """
    InfoDetailScreen {
        background: $surface;
    }
    #info-detail-header {
        height: 5;
        padding: 1 2;
        background: $error;
        color: $text;
    }
    #info-detail-title {
        text-style: bold;
    }
    #info-detail-meta {
        color: $text-muted;
    }
    #info-detail-content {
        height: 1fr;
        padding: 2 3;
    }
    .info-full-text {
        padding: 1;
        background: $panel;
        border: round $primary-darken-1;
        margin-bottom: 1;
    }
    .info-attachments {
        padding: 1;
        background: $panel;
        border: round $warning;
        margin-top: 1;
    }
    .att-btn {
        width: 100%;
        height: auto;
        min-height: 3;
        background: $warning 20%;
        border-left: thick $warning;
        margin-bottom: 1;
        text-align: left;
        padding: 1;
    }
    .att-btn:hover {
        background: $warning 40%;
    }
    .att-downloaded {
        border-left: thick $success;
        background: $success 15%;
    }
    """
    
    _attachments = []
    
    def __init__(self, info_obj, **kwargs):
        super().__init__(**kwargs)
        self._info = info_obj
        self._attachments = []
    
    def compose(self) -> ComposeResult:
        yield Header()
        info = self._info
        
        title = info.title if hasattr(info, 'title') and info.title else "Sans titre"
        author = info.author if hasattr(info, 'author') and info.author else "Inconnu"
        d = info.creation_date.strftime("%d/%m/%Y %H:%M") if hasattr(info, 'creation_date') and info.creation_date else ""
        read_status = "✅ Lu" if hasattr(info, 'read') and info.read else "🔔 Non lu"
        
        with Container(id="info-detail-header"):
            yield Static(f"📢 {title}", id="info-detail-title")
            yield Static(f"👤 {author}  │  📅 {d}  │  {read_status}", id="info-detail-meta")
        
        with ScrollableContainer(id="info-detail-content"):
            # Contenu complet
            content = ""
            if hasattr(info, 'content') and info.content:
                content = str(info.content)
            
            if content:
                yield Static(content, classes="info-full-text")
            else:
                yield Static("[dim]Aucun contenu texte[/]", classes="info-full-text")
            
            # Pièces jointes avec boutons de téléchargement
            if hasattr(info, 'attachments') and info.attachments:
                self._attachments = list(info.attachments)
            
            if self._attachments:
                yield Static("📎 [bold]Pièces jointes:[/]", classes="info-attachments")
                for i, att in enumerate(self._attachments):
                    name = att.name if hasattr(att, 'name') else str(att)
                    yield Button(f"📥 Télécharger: {name}", id=f"btn-att-{i}", classes="att-btn")
            
            yield Static(f"\n[dim]📂 Dossier de téléchargement: {Path.home() / 'Downloads'}[/]")
        
        yield Footer()
    
    def on_mount(self) -> None:
        # Marquer comme lu si possible
        try:
            if hasattr(self._info, 'mark_as_read'):
                self._info.mark_as_read(True)
        except Exception:
            pass
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id.startswith("btn-att-"):
            try:
                idx = int(btn_id.replace("btn-att-", ""))
                if 0 <= idx < len(self._attachments):
                    att = self._attachments[idx]
                    self._download_attachment(att, idx)
            except (ValueError, IndexError):
                pass
    
    @work(thread=True)
    def _download_attachment(self, att, idx: int) -> None:
        """Télécharge une pièce jointe dans ~/Downloads"""
        try:
            download_dir = Path.home() / "Downloads"
            download_dir.mkdir(parents=True, exist_ok=True)
            
            name = att.name if hasattr(att, 'name') else f"pj_{idx}"
            filepath = download_dir / name
            
            # pronotepy: att.save(path) ou att.save()
            if hasattr(att, 'save'):
                data = att.save()
                if data:
                    with open(filepath, 'wb') as f:
                        f.write(data)
                else:
                    # Certaines versions sauvegardent directement
                    att.save(str(filepath))
            elif hasattr(att, 'url') and att.url:
                import urllib.request
                urllib.request.urlretrieve(att.url, str(filepath))
            else:
                self.app.call_from_thread(
                    lambda: self.notify("❌ Téléchargement non supporté pour ce type", severity="error")
                )
                return
            
            self.app.call_from_thread(
                lambda: self.notify(f"✅ Téléchargé: {filepath}")
            )
            # Marquer visuellement le bouton
            try:
                btn = self.query_one(f"#btn-att-{idx}", Button)
                self.app.call_from_thread(lambda: btn.add_class("att-downloaded"))
                self.app.call_from_thread(lambda: setattr(btn, 'label', f"✅ Téléchargé: {name}"))
            except Exception:
                pass
            
        except Exception as e:
            self.app.call_from_thread(
                lambda: self.notify(f"❌ Erreur: {e}", severity="error")
            )
    
    def action_back(self) -> None:
        self.app.pop_screen()


# ═══════════════════════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRAN PARAMÈTRES
# ═══════════════════════════════════════════════════════════════════════════════

class SettingsScreen(Screen):
    """Page des paramètres"""
    
    BINDINGS = [
        Binding("escape", "back", "← Retour"),
    ]
    
    CSS = """
    SettingsScreen {
        align: center middle;
        background: $surface;
    }
    
    #settings-container {
        width: 90;
        height: auto;
        max-height: 95%;
        overflow-y: auto;
    }
    
    #settings-header {
        width: 100%;
        height: 5;
        background: $accent;
        border: round $accent;
        margin-bottom: 1;
    }
    
    #settings-title {
        text-align: center;
        width: 100%;
        text-style: bold;
        color: $text;
        padding-top: 1;
    }
    
    #settings-subtitle {
        text-align: center;
        width: 100%;
        color: $text-muted;
    }
    
    .settings-section {
        width: 100%;
        height: auto;
        background: $panel;
        border: round $primary-darken-1;
        padding: 2;
        margin-bottom: 1;
    }
    
    .section-title {
        text-style: bold;
        color: $primary;
        margin-bottom: 1;
    }
    
    .section-description {
        color: $text-muted;
        margin-bottom: 1;
    }
    
    .setting-row {
        layout: horizontal;
        height: auto;
        width: 100%;
        margin-bottom: 1;
        align: left middle;
    }
    
    .setting-label {
        width: 40%;
        color: $text;
    }
    
    .setting-value {
        width: 60%;
    }
    
    .setting-buttons {
        layout: horizontal;
        height: auto;
        width: 60%;
    }
    
    .setting-button {
        margin: 0 1;
        min-width: 15;
    }
    
    .danger-section {
        background: $error-darken-3;
        border: round $error;
    }
    
    .danger-button {
        background: $error;
    }
    
    .current-value {
        color: $success;
        text-style: bold;
    }
    """
    
    def compose(self) -> ComposeResult:
        config = load_config()
        creds = load_credentials()
        current_period = config.get("period_type", "Non configuré")
        has_creds = bool(creds.get("url"))
        
        with ScrollableContainer(id="settings-container"):
            # Header
            with Vertical(id="settings-header"):
                yield Static("⚙️ PARAMÈTRES", id="settings-title")
                yield Static("Personnalise ton expérience Pynote", id="settings-subtitle")
            
            # Section Période
            with Vertical(classes="settings-section"):
                yield Static("📚 Type de période", classes="section-title")
                yield Static("Change l'organisation de tes notes", classes="section-description")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Période actuelle:", classes="setting-label")
                    if current_period == "trimestre":
                        yield Static("📅 Trimestres", classes="setting-value current-value", id="period-display")
                    elif current_period == "semestre":
                        yield Static("📅 Semestres", classes="setting-value current-value", id="period-display")
                    else:
                        yield Static("❓ Non configuré", classes="setting-value", id="period-display")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Modifier:", classes="setting-label")
                    with Horizontal(classes="setting-buttons"):
                        yield Button("📅 Trimestres", id="btn-set-trimestre", classes="setting-button")
                        yield Button("📅 Semestres", id="btn-set-semestre", classes="setting-button")
            
            # Section Compte
            with Vertical(classes="settings-section"):
                yield Static("👤 Compte Pronote", classes="section-title")
                yield Static("Gère tes identifiants de connexion", classes="section-description")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Statut:", classes="setting-label")
                    if has_creds:
                        yield Static(f"✅ Identifiants sauvegardés\n[dim]URL: {creds.get('url', '?')[:40]}...\nUtilisateur: {creds.get('username', '?')}[/]", classes="setting-value")
                    else:
                        yield Static("❌ Aucun identifiant", classes="setting-value")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Actions:", classes="setting-label")
                    with Horizontal(classes="setting-buttons"):
                        yield Button("✏️ Modifier", id="btn-change-account", classes="setting-button")
                        if has_creds:
                            yield Button("🗑️ Supprimer", id="btn-delete-creds", classes="setting-button danger-button")
            
            # Section Apparence
            with Vertical(classes="settings-section"):
                yield Static("🎨 Apparence", classes="section-title")
                yield Static("Personnalise l'interface", classes="section-description")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Thème:", classes="setting-label")
                    theme_text = "🌙 Sombre" if self.app.theme == "textual-dark" else "☀️ Clair"
                    yield Static(theme_text, classes="setting-value current-value", id="theme-display")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Changer:", classes="setting-label")
                    with Horizontal(classes="setting-buttons"):
                        yield Button("🔄 Basculer thème", id="btn-toggle-theme", classes="setting-button")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Vue EDT:", classes="setting-label")
                    edt_mode = config.get("edt_view", "table")
                    edt_text = "📊 Tableau" if edt_mode == "table" else "📋 Liste"
                    yield Static(edt_text, classes="setting-value current-value", id="edt-view-display")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Changer:", classes="setting-label")
                    with Horizontal(classes="setting-buttons"):
                        yield Button("📊 Tableau", id="btn-edt-table", classes="setting-button")
                        yield Button("📋 Liste", id="btn-edt-list", classes="setting-button")
            
            # Section Export
            with Vertical(classes="settings-section"):
                yield Static("📤 Export des données", classes="section-title")
                yield Static("Exporte tes notes en fichier CSV ou JSON", classes="section-description")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Format:", classes="setting-label")
                    with Horizontal(classes="setting-buttons"):
                        yield Button("📤 Export CSV", id="btn-export-csv", classes="setting-button")
                        yield Button("📤 Export JSON", id="btn-export-json", classes="setting-button")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Bulletin:", classes="setting-label")
                    with Horizontal(classes="setting-buttons"):
                        yield Button("📄 Export HTML", id="btn-export-html", classes="setting-button")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Destination:", classes="setting-label")
                    yield Static(f"[dim]{Path.home()}[/]", classes="setting-value")
            
            # Section Informations
            with Vertical(classes="settings-section"):
                yield Static("ℹ️ Informations", classes="section-title")
                yield Static(f"Version: {APP_VERSION}", classes="section-description")
                yield Static(f"Fichier config: {CONFIG_FILE}", classes="section-description")
                yield Static(f"Fichier identifiants: {CREDENTIALS_FILE}", classes="section-description")
            
            # Section Danger
            with Vertical(classes="settings-section danger-section"):
                yield Static("⚠️ Zone dangereuse", classes="section-title")
                yield Static("Actions irréversibles", classes="section-description")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Réinitialiser:", classes="setting-label")
                    with Horizontal(classes="setting-buttons"):
                        yield Button("🔥 Effacer config", id="btn-reset-config", classes="setting-button danger-button")
                        yield Button("🚪 Déconnexion", id="btn-logout", classes="setting-button danger-button")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Gère les actions des boutons"""
        btn_id = event.button.id
        
        # Période
        if btn_id == "btn-set-trimestre":
            save_config({"period_type": "trimestre"})
            self.app.config = {"period_type": "trimestre"}
            
            # Mettre à jour l'affichage
            try:
                period_display = self.query_one("#period-display", Static)
                period_display.update("📅 Trimestres")
                period_display.add_class("current-value")
            except Exception:
                pass
            
            self.notify("✅ Période changée en Trimestres")
            
        elif btn_id == "btn-set-semestre":
            save_config({"period_type": "semestre"})
            self.app.config = {"period_type": "semestre"}
            
            # Mettre à jour l'affichage
            try:
                period_display = self.query_one("#period-display", Static)
                period_display.update("📅 Semestres")
                period_display.add_class("current-value")
            except Exception:
                pass
            
            self.notify("✅ Période changée en Semestres")
        
        # Compte
        elif btn_id == "btn-change-account":
            self.app.client = None
            delete_credentials()
            self.app.pop_screen()
            self.app.pop_screen()
            self.app.push_screen("login")
            self.notify("🔄 Reconnectez-vous avec un nouveau compte")
            
        elif btn_id == "btn-delete-creds":
            delete_credentials()
            self.notify("🗑️ Identifiants supprimés")
            self.refresh()
        
        # Apparence
        elif btn_id == "btn-toggle-theme":
            if self.app.theme == "textual-dark":
                self.app.theme = "textual-light"
                theme_text = "☀️ Clair"
            else:
                self.app.theme = "textual-dark"
                theme_text = "🌙 Sombre"
            
            theme_display = self.query_one("#theme-display", Static)
            theme_display.update(theme_text)
            self.notify(f"🎨 Thème changé: {theme_text}")
        
        # Vue EDT
        elif btn_id == "btn-edt-table":
            config = load_config()
            config["edt_view"] = "table"
            save_config(config)
            try:
                edt_display = self.query_one("#edt-view-display", Static)
                edt_display.update("📊 Tableau")
            except Exception:
                pass
            self.notify("📊 EDT en mode Tableau")
        
        elif btn_id == "btn-edt-list":
            config = load_config()
            config["edt_view"] = "list"
            save_config(config)
            try:
                edt_display = self.query_one("#edt-view-display", Static)
                edt_display.update("📋 Liste")
            except Exception:
                pass
            self.notify("📋 EDT en mode Liste")
        
        # Export
        elif btn_id == "btn-export-csv":
            self._export_notes("csv")
        elif btn_id == "btn-export-json":
            self._export_notes("json")
        elif btn_id == "btn-export-html":
            self._export_bulletin()
        
        # Danger
        elif btn_id == "btn-reset-config":
            if CONFIG_FILE.exists():
                CONFIG_FILE.unlink()
            self.app.config = {}
            self.notify("🔥 Configuration réinitialisée")
            self.refresh()
            
        elif btn_id == "btn-logout":
            self.app.client = None
            self.app.pop_screen()
            self.app.pop_screen()
            self.notify("👋 Déconnecté")
    
    def _export_notes(self, fmt: str) -> None:
        """Exporte les notes de la période courante en CSV ou JSON"""
        try:
            c = self.app.client
            if not c:
                self.notify("❌ Non connecté", severity="error")
                return
            
            period = c.current_period
            if not period:
                self.notify("❌ Aucune période active", severity="error")
                return
            
            grades = list(period.grades) if hasattr(period, 'grades') and period.grades else []
            if not grades:
                self.notify("❌ Aucune note à exporter", severity="error")
                return
            
            filepath = Path.home() / f"pynote_notes_{period.name or 'export'}.{fmt}"
            if fmt == "csv":
                export_notes_csv(grades, str(filepath))
            else:
                export_notes_json(grades, str(filepath))
            
            self.notify(f"✅ Exporté: {filepath}")
        except Exception as e:
            self.notify(f"❌ Erreur export: {e}", severity="error")
    
    def _export_bulletin(self) -> None:
        """Exporte un bulletin HTML et l'ouvre dans le navigateur"""
        try:
            c = self.app.client
            if not c:
                self.notify("❌ Non connecté", severity="error")
                return
            
            period = c.current_period
            if not period:
                self.notify("❌ Aucune période active", severity="error")
                return
            
            filepath = export_bulletin_html(c, period)
            self.notify(f"✅ Bulletin exporté: {filepath}")
            
            # Ouvrir dans le navigateur
            try:
                webbrowser.open(f"file:///{filepath}")
            except Exception:
                pass
        except Exception as e:
            self.notify(f"❌ Erreur bulletin: {e}", severity="error")
    
    def action_back(self) -> None:
        """Retour au dashboard"""
        self.app.pop_screen()


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRAN SIMULATEUR
# ═══════════════════════════════════════════════════════════════════════════════

class SimulatorScreen(Screen):
    """Simulateur de notes avancé — calcule moyennes matières puis moyenne générale"""
    
    BINDINGS = [
        Binding("escape", "back", "← Retour"),
    ]
    
    CSS = """
    SimulatorScreen {
        background: $surface;
    }
    #sim-header {
        height: 3;
        background: $accent;
        padding: 1;
        text-style: bold;
        color: $text;
    }
    #sim-form {
        height: auto;
        padding: 1 2;
        background: $panel;
        border-bottom: solid $primary-darken-1;
    }
    #sim-form Horizontal {
        height: auto;
        margin-bottom: 1;
        align: left middle;
    }
    #sim-form Select {
        width: 22;
        margin: 0 1;
    }
    #sim-form Input {
        width: 12;
        margin: 0 1;
    }
    #sim-form Static {
        width: auto;
        padding: 0 1;
    }
    #sim-form Button {
        margin: 0 1;
    }
    #btn-sim-add {
        background: $success;
    }
    #btn-sim-clear {
        background: $error;
    }
    #sim-notes-list {
        height: auto;
        max-height: 40%;
        padding: 1 2;
        background: $panel;
        border-bottom: solid $primary-darken-1;
    }
    .sim-note-item {
        height: auto;
        padding: 0 1;
        margin-bottom: 0;
    }
    #sim-results {
        height: 1fr;
        padding: 1 2;
    }
    """

    simulated_notes = []
    
    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="sim-header"):
            yield Static("🧮 SIMULATEUR DE NOTES")
        
        with Vertical(id="sim-form"):
            with Horizontal():
                yield Static("Matière:")
                yield Select([("Chargement...", "")], id="sim-subject", allow_blank=False, value="")
            with Horizontal():
                yield Static("Note:")
                yield Input(placeholder="15", id="sim-note", type="number")
                yield Static("/")
                yield Input(placeholder="20", id="sim-out-of", value="20", type="number")
                yield Static("Coef:")
                yield Input(placeholder="1", id="sim-coef", value="1", type="number")
            with Horizontal():
                yield Button("➕ Ajouter", id="btn-sim-add")
                yield Button("🗑️ Tout effacer", id="btn-sim-clear")
                yield Button("🧮 Calculer", id="btn-sim-calc", variant="primary")
        
        yield ScrollableContainer(id="sim-notes-list")
        yield ScrollableContainer(id="sim-results")
        yield Footer()
    
    def on_mount(self) -> None:
        self.simulated_notes = []
        self._populate_subjects()
    
    def _populate_subjects(self) -> None:
        """Peuple la liste des matières depuis la période courante"""
        try:
            c = self.app.client
            period = c.current_period
            options = [("— Toutes matières —", "")]
            if period and hasattr(period, 'averages') and period.averages:
                for a in period.averages:
                    if a.subject and a.subject.name:
                        options.append((a.subject.name, a.subject.name))
            self.query_one("#sim-subject", Select).set_options(options)
        except Exception:
            pass
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-sim-add":
            self._add_note()
        elif event.button.id == "btn-sim-clear":
            self.simulated_notes = []
            self._refresh_notes_list()
            self._clear_results()
        elif event.button.id == "btn-sim-calc":
            self._calculate()
    
    def _add_note(self) -> None:
        """Ajoute une note simulée à la liste"""
        try:
            subject = self.query_one("#sim-subject", Select).value
            note_val = self.query_one("#sim-note", Input).value
            out_val = self.query_one("#sim-out-of", Input).value
            coef_val = self.query_one("#sim-coef", Input).value
            
            note = float(note_val.replace(",", "."))
            out_of = float(out_val.replace(",", ".")) if out_val else 20.0
            coef = float(coef_val.replace(",", ".")) if coef_val else 1.0
            
            subject_name = str(subject) if subject else "Toutes"
            
            self.simulated_notes.append({
                "subject": subject_name,
                "note": note,
                "out_of": out_of,
                "coef": coef,
                "note_20": (note / out_of) * 20,
            })
            
            self._refresh_notes_list()
            self.query_one("#sim-note", Input).value = ""
            self.notify(f"✅ Note ajoutée: {note}/{out_of} en {subject_name}")
        except ValueError:
            self.notify("❌ Valeurs invalides", severity="error")
        except Exception as e:
            self.notify(f"❌ Erreur: {e}", severity="error")
    
    def _refresh_notes_list(self) -> None:
        """Rafraîchit l'affichage des notes simulées"""
        container = self.query_one("#sim-notes-list", ScrollableContainer)
        for child in list(container.children):
            child.remove()
        
        if not self.simulated_notes:
            container.mount(Static("[dim]Aucune note simulée. Ajoutez des notes ci-dessus.[/]", classes="sim-note-item"))
            return
        
        container.mount(Static(f"[bold]📋 Notes simulées ({len(self.simulated_notes)}):[/]", classes="sim-note-item"))
        for i, n in enumerate(self.simulated_notes):
            color = "green" if n["note_20"] >= 14 else "yellow" if n["note_20"] >= 10 else "red"
            container.mount(Static(
                f"  {i+1}. [{color}]{n['note']}/{n['out_of']}[/] (coef {n['coef']}) — {n['subject']}",
                classes="sim-note-item"
            ))
    
    def _clear_results(self) -> None:
        container = self.query_one("#sim-results", ScrollableContainer)
        for child in list(container.children):
            child.remove()
    
    def _calculate(self) -> None:
        """Calcul correct: moyennes par matière → moyenne générale"""
        results = self.query_one("#sim-results", ScrollableContainer)
        for child in list(results.children):
            child.remove()
        
        try:
            c = self.app.client
            period = c.current_period
            if not period:
                results.mount(Static("[red]❌ Aucune période active[/]"))
                return
            
            # 1) Collecter les notes réelles par matière
            subjects = {}  # {nom: {"notes": [(note_20, coef)], "class_avg": float}}
            
            if hasattr(period, 'grades') and period.grades:
                for g in period.grades:
                    subj = g.subject.name if g.subject else "?"
                    try:
                        val = float(str(g.grade).replace(",", "."))
                        out = float(str(g.out_of).replace(",", ".")) if g.out_of else 20.0
                        coef = float(str(g.coefficient).replace(",", ".")) if g.coefficient else 1.0
                        note_20 = (val / out) * 20
                        if subj not in subjects:
                            subjects[subj] = {"notes": [], "class_avg": None}
                        subjects[subj]["notes"].append((note_20, coef))
                    except (ValueError, AttributeError):
                        pass
            
            # Récupérer les moyennes de classe par matière
            if hasattr(period, 'averages') and period.averages:
                for a in period.averages:
                    subj = a.subject.name if a.subject else "?"
                    if subj not in subjects:
                        subjects[subj] = {"notes": [], "class_avg": None}
                    try:
                        subjects[subj]["class_avg"] = float(str(a.class_average).replace(",", ".")) if a.class_average else None
                    except (ValueError, AttributeError):
                        pass
            
            # 2) Ajouter les notes simulées
            for sn in self.simulated_notes:
                target = sn["subject"]
                if not target:
                    # Note sans matière → on l'ajoute à toutes les matières (non)
                    # On crée une matière "Simulé"
                    target = "Simulé"
                if target not in subjects:
                    subjects[target] = {"notes": [], "class_avg": None}
                subjects[target]["notes"].append((sn["note_20"], sn["coef"]))
            
            if not subjects:
                results.mount(Static("[yellow]Aucune donnée disponible[/]"))
                return
            
            # 3) Calculer la moyenne de chaque matière (somme pondérée)
            subject_averages = {}
            results.mount(Static("[bold]📊 MOYENNES PAR MATIÈRE[/]", classes="sim-note-item"))
            
            for subj in sorted(subjects.keys()):
                data = subjects[subj]
                if not data["notes"]:
                    continue
                total_weighted = sum(n * c for n, c in data["notes"])
                total_coef = sum(c for _, c in data["notes"])
                if total_coef == 0:
                    continue
                avg = total_weighted / total_coef
                subject_averages[subj] = avg
                
                color = "green" if avg >= 14 else "yellow" if avg >= 10 else "red"
                nb = len(data["notes"])
                cls_info = f" │ Classe: {data['class_avg']}" if data['class_avg'] else ""
                
                # Vérifier si matière a des notes simulées
                sim_in_subj = [s for s in self.simulated_notes if s["subject"] == subj]
                sim_marker = f" [bold magenta](+{len(sim_in_subj)} sim)[/]" if sim_in_subj else ""
                
                results.mount(Static(
                    f"  📖 [bold]{subj}[/]: [{color}]{avg:.4f}/20[/] ({nb} notes){cls_info}{sim_marker}",
                    classes="sim-note-item"
                ))
            
            # 4) Moyenne générale = moyenne des moyennes par matière (non pondérée)
            if subject_averages:
                overall = sum(subject_averages.values()) / len(subject_averages)
                color = "green" if overall >= 14 else "yellow" if overall >= 10 else "red"
                
                results.mount(Static(""))
                results.mount(Static(f"[bold]📊 MOYENNE GÉNÉRALE[/]", classes="sim-note-item"))
                results.mount(Static(
                    f"  [{color}][bold]{overall:.4f}/20[/][/]  ({len(subject_averages)} matières)",
                    classes="sim-note-item"
                ))
                
                # Comparaison avec la moyenne actuelle
                if hasattr(period, 'overall_average') and period.overall_average:
                    try:
                        current = float(str(period.overall_average).replace(",", "."))
                        diff = overall - current
                        sign = "+" if diff >= 0 else ""
                        dc = "green" if diff >= 0 else "red"
                        results.mount(Static(
                            f"  Actuelle: {current:.4f} → Simulée: [{dc}]{overall:.4f}[/] ([{dc}]{sign}{diff:.4f}[/])",
                            classes="sim-note-item"
                        ))
                    except (ValueError, AttributeError):
                        pass
            else:
                results.mount(Static("[yellow]Aucune note disponible[/]"))
                
        except Exception as e:
            results.mount(Static(f"[red]❌ Erreur: {e}[/]"))
    
    def action_back(self) -> None:
        self.app.pop_screen()


# ═══════════════════════════════════════════════════════════════════════════════
# APPLICATION
# ═══════════════════════════════════════════════════════════════════════════════

class PynoteApp(App):
    """Application Pynote - Client Pronote coloré"""

    CSS = """
    /* Thème clair personnalisé */
    App.-light-mode {
        background: #f0f4f8;
    }
    """

    TITLE = "🎓 Pynote"
    
    BINDINGS = [
        Binding("ctrl+q", "quit", "Quitter", priority=True),
        Binding("ctrl+t", "toggle_dark", "Thème", priority=True),
    ]

    SCREENS = {
        "license": LicenseScreen,
        "login": LoginScreen,
        "config": ConfigScreen,
        "dashboard": DashboardScreen,
        "settings": SettingsScreen,
        "edt": EdtScreen,
        "notes": NotesScreen,
        "devoirs": DevoirsScreen,
        "vie": VieScreen,
        "cantine": CantineScreen,
        "competences": CompetencesScreen,
        "infos": InfosScreen,
        "simulator": SimulatorScreen,
    }

    def __init__(self):
        super().__init__()
        self.client = None
        self.config = load_config()

    def on_mount(self) -> None:
        if is_license_accepted():
            self.push_screen("login")
        else:
            self.push_screen("license")

    def action_toggle_dark(self) -> None:
        if self.theme == "textual-light":
            self.theme = "textual-dark"
            self.remove_class("-light-mode")
        else:
            self.theme = "textual-light"
            self.add_class("-light-mode")


if __name__ == "__main__":
    PynoteApp().run()
