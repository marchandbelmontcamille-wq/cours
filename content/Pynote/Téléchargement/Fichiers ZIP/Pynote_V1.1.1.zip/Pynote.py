"""
🎓 Pynote - Dashboard coloré avec sauvegarde des identifiants
"""

import os
import sys
import json
import urllib.request
import webbrowser
from pathlib import Path
from datetime import datetime, timedelta, date
from dotenv import load_dotenv

import pronotepy
from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, Vertical, ScrollableContainer, Grid
from textual.widgets import (
    Header, Footer, Static, Button, Label, Input, Rule, ProgressBar, Checkbox, Switch,
)
from textual.screen import Screen
from textual.binding import Binding
from textual import work

load_dotenv()

# ═══════════════════════════════════════════════════════════════════════════════
# VERSION ET MISE À JOUR
# ═══════════════════════════════════════════════════════════════════════════════

APP_VERSION = "1.1.1"
APP_NAME = "Pynote"

# URL du site de mise à jour
UPDATE_URL = "https://cours.cmarbel15.xyz/Pynote/version.json"
DOWNLOAD_URL = "https://cours.cmarbel15.xyz/Pynote/Pynote"
LICENSE_URL = "https://cours.cmarbel15.xyz/Pynote/Licence-Pynote"

# Fichiers de sauvegarde
CREDENTIALS_FILE = Path.home() / ".pynote_credentials.json"
CONFIG_FILE = Path.home() / ".pynote_config.json"
LICENSE_FILE = Path.home() / ".pynote_license_accepted"


def check_for_update() -> dict:
    """
    Vérifie si une mise à jour est disponible.
    Retourne un dict avec les infos de mise à jour ou None si erreur.
    """
    try:
        req = urllib.request.Request(
            UPDATE_URL,
            headers={'User-Agent': f'{APP_NAME}/{APP_VERSION}'}
        )
        with urllib.request.urlopen(req, timeout=5) as response:
            data = json.loads(response.read().decode('utf-8'))
            
            remote_version = data.get("version", "0.0.0")
            
            # Comparer les versions
            local_parts = [int(x) for x in APP_VERSION.split(".")]
            remote_parts = [int(x) for x in remote_version.split(".")]
            
            update_available = remote_parts > local_parts
            
            return {
                "update_available": update_available,
                "current_version": APP_VERSION,
                "latest_version": remote_version,
                "changelog": data.get("changelog", ""),
                "download_url": data.get("download_url", DOWNLOAD_URL),
                "release_date": data.get("release_date", ""),
            }
    except Exception as e:
        return {
            "update_available": False,
            "current_version": APP_VERSION,
            "error": str(e)
        }


def open_download_page(url: str = None) -> bool:
    """Ouvre la page de téléchargement dans le navigateur."""
    try:
        webbrowser.open(url or DOWNLOAD_URL)
        return True
    except Exception:
        return False


def save_credentials(url: str, username: str, password: str) -> None:
    """Sauvegarde les identifiants"""
    data = {"url": url, "username": username, "password": password}
    with open(CREDENTIALS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f)


def load_credentials() -> dict:
    """Charge les identifiants sauvegardés"""
    if CREDENTIALS_FILE.exists():
        try:
            with open(CREDENTIALS_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"url": "", "username": "", "password": ""}


def delete_credentials() -> None:
    """Supprime les identifiants sauvegardés"""
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()


def save_config(config: dict) -> None:
    """Sauvegarde la configuration"""
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f)


def load_config() -> dict:
    """Charge la configuration"""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def config_exists() -> bool:
    """Vérifie si la configuration existe"""
    return CONFIG_FILE.exists()


def is_license_accepted() -> bool:
    """Vérifie si la licence a été acceptée"""
    return LICENSE_FILE.exists()


def accept_license() -> None:
    """Marque la licence comme acceptée"""
    with open(LICENSE_FILE, "w", encoding="utf-8") as f:
        f.write("accepted")


def fetch_license_text() -> str:
    """Récupère le texte de la licence depuis le serveur"""
    try:
        req = urllib.request.Request(
            LICENSE_URL,
            headers={'User-Agent': f'{APP_NAME}/{APP_VERSION}'}
        )
        with urllib.request.urlopen(req, timeout=10) as response:
            return response.read().decode('utf-8')
    except Exception as e:
        return f"Impossible de charger la licence.\nErreur: {e}\n\nVeuillez vérifier votre connexion internet."


# ═══════════════════════════════════════════════════════════════════════════════
# WIDGETS DASHBOARD
# ═══════════════════════════════════════════════════════════════════════════════

class DashboardCard(Static):
    """Carte colorée du dashboard"""
    
    def __init__(self, title: str, icon: str, btn_id: str, color: str = "primary", **kwargs):
        super().__init__(**kwargs)
        self.title_text = title
        self.icon = icon
        self.btn_id = btn_id
        self.color = color
        self.add_class(f"card-{color}")

    def compose(self) -> ComposeResult:
        yield Static(f"{self.icon} {self.title_text}", classes="card-title")
        yield Static("Chargement...", classes="card-content", id=f"content-{self.btn_id}")
        yield Button("Voir détails →", id=self.btn_id, classes="card-btn")


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRAN DE LICENCE
# ═══════════════════════════════════════════════════════════════════════════════

class LicenseScreen(Screen):
    """Écran d'acceptation de la licence au premier lancement"""

    CSS = """
    LicenseScreen {
        align: center middle;
        background: $surface;
    }
    
    #license-container {
        width: 90;
        height: auto;
        max-height: 95%;
    }
    
    #license-header {
        width: 100%;
        height: 5;
        background: $warning;
        border: round $warning;
        margin-bottom: 1;
    }
    
    #license-title {
        text-align: center;
        width: 100%;
        text-style: bold;
        color: $text;
        padding-top: 1;
    }
    
    #license-subtitle {
        text-align: center;
        width: 100%;
        color: $text-muted;
    }
    
    #license-info {
        width: 100%;
        height: auto;
        background: $panel;
        border: round $warning-darken-1;
        padding: 2;
        content-align: center middle;
    }
    
    #license-link {
        text-align: center;
        width: 100%;
        color: $primary;
        text-style: bold;
        margin: 1 0;
    }
    
    #license-note {
        text-align: center;
        width: 100%;
        color: $text-muted;
    }
    
    #btn-open-license {
        margin: 1 2;
        min-width: 30;
    }
    
    #license-buttons {
        layout: horizontal;
        height: auto;
        width: 100%;
        margin-top: 1;
        align: center middle;
    }
    
    .license-btn {
        margin: 0 2;
        min-width: 25;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="license-container"):
            with Vertical(id="license-header"):
                yield Static("📜 LICENCE PYNOTE", id="license-title")
                yield Static("Veuillez lire et accepter la licence", id="license-subtitle")
            
            with Vertical(id="license-info"):
                yield Static("📄 Lien vers la licence :", id="license-note")
                yield Static(f"🔗 {LICENSE_URL}", id="license-link")
                yield Button("🌐 Ouvrir dans le navigateur", id="btn-open-license")
            
            with Horizontal(id="license-buttons"):
                yield Button("❌ Refuser", id="btn-license-refuse", classes="license-btn", variant="error")
                yield Button("✅ J'accepte la licence", id="btn-license-accept", classes="license-btn", variant="success")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-open-license":
            webbrowser.open(LICENSE_URL)
            self.notify("🌐 Ouverture du navigateur...")
        elif event.button.id == "btn-license-accept":
            accept_license()
            self.app.pop_screen()
            self.app.push_screen("login")
        elif event.button.id == "btn-license-refuse":
            self.app.exit()


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRAN DE CONNEXION
# ═══════════════════════════════════════════════════════════════════════════════

class LoginScreen(Screen):
    """Connexion avec sauvegarde"""

    CSS = """
    LoginScreen {
        align: center middle;
        background: $surface;
        overflow-y: auto;
    }
    
    #login-container {
        width: 80;
        height: auto;
        min-height: 20;
        max-height: 95%;
        padding: 1;
    }
    
    #login-header {
        width: 100%;
        height: 5;
        background: $primary;
        border: round $primary;
        margin-bottom: 1;
    }
    
    #login-icon {
        display: none;
    }
    
    #login-title {
        text-align: center;
        width: 100%;
        text-style: bold;
        color: $text;
    }
    
    #login-subtitle {
        text-align: center;
        width: 100%;
        color: $text-muted;
    }
    
    #login-form {
        width: 100%;
        height: auto;
        background: $panel;
        border: round $primary-darken-1;
        padding: 1 2;
    }
    
    .field-row {
        layout: horizontal;
        height: auto;
        width: 100%;
        margin-bottom: 1;
    }
    
    .field-label {
        color: $primary;
        text-style: bold;
        width: 20;
        padding-top: 1;
    }
    
    .field-input {
        width: 1fr;
    }
    
    #action-row {
        layout: horizontal;
        height: auto;
        width: 100%;
        margin-top: 1;
        align: left middle;
    }
    
    #save-check {
        width: auto;
    }
    
    #btn-connect {
        width: auto;
        min-width: 20;
        margin-left: 2;
    }
    
    #status {
        text-align: center;
        height: 2;
        margin-top: 1;
    }
    
    .status-error { color: $error; }
    .status-loading { color: $warning; }
    .status-success { color: $success; }
    
    #login-footer {
        text-align: center;
        color: $text-muted;
        margin-top: 1;
    }
    """

    def compose(self) -> ComposeResult:
        creds = load_credentials()
        env_url = os.getenv("PRONOTE_URL", "")
        env_user = os.getenv("PRONOTE_USERNAME", "")
        env_pass = os.getenv("PRONOTE_PASSWORD", "")
        
        url = creds.get("url") or env_url
        user = creds.get("username") or env_user
        pwd = creds.get("password") or env_pass
        
        with Vertical(id="login-container"):
            with Vertical(id="login-header"):
                yield Static("🎓", id="login-icon")
                yield Static("🎓 PYNOTE", id="login-title")
                yield Static("Connectez-vous à Pronote", id="login-subtitle")
            
            with Vertical(id="login-form"):
                with Horizontal(classes="field-row"):
                    yield Label("🌐 URL", classes="field-label")
                    yield Input(placeholder="https://..../pronote/eleve.html?login=true", id="url", value=url, classes="field-input")
                
                with Horizontal(classes="field-row"):
                    yield Label("👤 Identifiant", classes="field-label")
                    yield Input(placeholder="Votre identifiant", id="user", value=user, classes="field-input")
                
                with Horizontal(classes="field-row"):
                    yield Label("🔒 Mot de passe", classes="field-label")
                    yield Input(placeholder="••••••••", id="pwd", password=True, value=pwd, classes="field-input")
                
                with Horizontal(id="action-row"):
                    yield Checkbox("💾 Se souvenir", id="save-check", value=bool(creds.get("url")))
                    yield Button("🚀 Connexion", id="btn-connect", variant="success")
                
                yield Static("", id="status")
            
            yield Static("🔐 Stockage local sécurisé", id="login-footer")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-connect":
            self._login()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        self._login()

    def _login(self) -> None:
        url = self.query_one("#url", Input).value.strip()
        user = self.query_one("#user", Input).value.strip()
        pwd = self.query_one("#pwd", Input).value
        save = self.query_one("#save-check", Checkbox).value
        status = self.query_one("#status", Static)
        
        if not all([url, user, pwd]):
            status.remove_class("status-loading", "status-success")
            status.add_class("status-error")
            status.update("❌ Veuillez remplir tous les champs")
            return
        
        status.remove_class("status-error", "status-success")
        status.add_class("status-loading")
        status.update("⏳ Connexion en cours...")
        
        self._do_login(url, user, pwd, save)

    @work(thread=True)
    def _do_login(self, url: str, user: str, pwd: str, save: bool) -> None:
        try:
            client = pronotepy.Client(url, username=user, password=pwd)
            if client.logged_in:
                # Sauvegarder si demandé
                if save:
                    save_credentials(url, user, pwd)
                else:
                    delete_credentials()
                
                self.app.client = client
                self.app.call_from_thread(self._success)
            else:
                self.app.call_from_thread(self._error, "Identifiants incorrects")
        except pronotepy.ENTLoginError as e:
            self.app.call_from_thread(self._error, f"Erreur ENT: {str(e)[:35]}")
        except pronotepy.PronoteAPIError as e:
            # Erreurs spécifiques de l'API Pronote
            error_msg = str(e)
            if "23" in error_msg:
                self.app.call_from_thread(self._error, "Session expirée, réessayez")
            else:
                self.app.call_from_thread(self._error, f"Erreur Pronote: {error_msg[:30]}")
        except Exception as e:
            error_str = str(e)
            if "23" in error_str:
                self.app.call_from_thread(self._error, "Trop de connexions, patiente...")
            else:
                self.app.call_from_thread(self._error, error_str[:40])

    def _success(self) -> None:
        status = self.query_one("#status", Static)
        status.remove_class("status-loading", "status-error")
        status.add_class("status-success")
        status.update("✅ Connexion réussie !")
        # Vérifier si la config existe
        if config_exists():
            self.app.push_screen("dashboard")
        else:
            self.app.push_screen("config")

    def _error(self, msg: str) -> None:
        status = self.query_one("#status", Static)
        status.remove_class("status-loading", "status-success")
        status.add_class("status-error")
        status.update(f"❌ {msg}")


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRAN DE CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════════

class ConfigScreen(Screen):
    """Configuration initiale"""

    CSS = """
    ConfigScreen {
        align: center middle;
        background: $surface;
    }
    
    #config-container {
        width: 65;
        height: auto;
    }
    
    #config-header {
        width: 100%;
        height: 5;
        background: $secondary;
        border: round $secondary;
        margin-bottom: 1;
    }
    
    #config-icon {
        text-align: center;
        width: 100%;
        color: $text;
    }
    
    #config-title {
        text-align: center;
        width: 100%;
        text-style: bold;
        color: $text;
    }
    
    #config-form {
        width: 100%;
        height: auto;
        background: $panel;
        border: round $secondary-darken-1;
        padding: 2;
    }
    
    .config-question {
        text-align: center;
        margin-bottom: 1;
    }
    
    .config-buttons {
        height: auto;
        margin-top: 1;
    }
    
    .config-btn {
        width: 50%;
        margin: 0 1;
    }
    """

    def compose(self) -> ComposeResult:
        with Vertical(id="config-container"):
            with Vertical(id="config-header"):
                yield Static("⚙️", id="config-icon")
                yield Static("CONFIGURATION", id="config-title")
            
            with Vertical(id="config-form"):
                yield Static("📚 Comment sont organisées tes notes ?", classes="config-question")
                yield Static("(Trimestres ou Semestres)", classes="config-question")
                
                with Horizontal(classes="config-buttons"):
                    yield Button("📅 Trimestres", id="btn-trimestre", variant="primary", classes="config-btn")
                    yield Button("📅 Semestres", id="btn-semestre", variant="success", classes="config-btn")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-trimestre":
            save_config({"period_type": "trimestre"})
            self.app.config = {"period_type": "trimestre"}
            self.app.push_screen("dashboard")
        elif event.button.id == "btn-semestre":
            save_config({"period_type": "semestre"})
            self.app.config = {"period_type": "semestre"}
            self.app.push_screen("dashboard")


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRAN DASHBOARD
# ═══════════════════════════════════════════════════════════════════════════════

class DashboardScreen(Screen):
    """Dashboard coloré"""

    BINDINGS = [
        Binding("r", "refresh", "Actualiser"),
        Binding("s", "settings", "Paramètres"),
        Binding("escape", "logout", "Déconnexion"),
    ]

    CSS = """
    DashboardScreen { layout: vertical; background: $surface; }
    
    #update-bar {
        height: 5;
        background: $warning;
        padding: 1 3;
        layout: horizontal;
        align: center middle;
        display: none;
    }
    
    #update-bar.visible {
        display: block;
    }
    
    #update-bar #update-text {
        width: 1fr;
        color: $text;
        text-style: bold;
        padding-right: 2;
    }
    
    #update-bar Button {
        margin-left: 1;
        min-width: 16;
    }
    
    #update-bar #btn-download-update {
        background: $success;
    }
    
    #update-bar #btn-dismiss-update {
        background: $error;
        min-width: 10;
    }
    
    #welcome-bar {
        height: 5;
        background: $primary;
        padding: 1 2;
        layout: horizontal;
        align: center middle;
    }
    
    #welcome-text {
        text-style: bold;
        color: $text;
        width: auto;
    }
    
    #welcome-date {
        color: $text-muted;
        width: 1fr;
        padding-left: 2;
    }
    
    #btn-settings-header {
        background: white;
        color: $primary;
        border: thick white;
        min-width: 20;
        height: 3;
        text-style: bold;
    }
    
    #btn-settings-header:hover {
        background: $primary-lighten-3;
        color: white;
    }
    
    #dashboard-grid {
        layout: grid;
        grid-size: 3 1;
        grid-gutter: 2;
        padding: 2;
        height: 1fr;
    }
    
    /* Cartes colorées */
    DashboardCard {
        height: 100%;
        padding: 1;
        background: $panel;
    }
    
    .card-blue {
        border: thick $primary;
        border-title-color: $primary;
    }
    
    .card-green {
        border: thick $success;
        border-title-color: $success;
    }
    
    .card-orange {
        border: thick $warning;
        border-title-color: $warning;
    }
    
    .card-red {
        border: thick $error;
        border-title-color: $error;
    }
    
    .card-purple {
        border: thick $accent;
        border-title-color: $accent;
    }
    
    .card-title {
        text-style: bold;
        padding-bottom: 1;
        margin-bottom: 1;
    }
    
    .card-blue .card-title { color: $primary; border-bottom: solid $primary; }
    .card-green .card-title { color: $success; border-bottom: solid $success; }
    .card-orange .card-title { color: $warning; border-bottom: solid $warning; }
    .card-red .card-title { color: $error; border-bottom: solid $error; }
    .card-purple .card-title { color: $accent; border-bottom: solid $accent; }
    
    .card-content {
        height: 1fr;
        overflow: auto;
    }
    
    .card-btn {
        dock: bottom;
        width: 100%;
        margin-top: 1;
    }
    
    .card-blue .card-btn { background: $primary; }
    .card-green .card-btn { background: $success; }
    .card-orange .card-btn { background: $warning; }
    .card-red .card-btn { background: $error; }
    
    /* Contenu */
    .highlight-good { color: $success; text-style: bold; }
    .highlight-warn { color: $warning; text-style: bold; }
    .highlight-bad { color: $error; text-style: bold; }
    .highlight-info { color: $primary; text-style: bold; }
    """

    # Variable pour stocker les infos de mise à jour
    update_info = None
    
    def compose(self) -> ComposeResult:
        # Format de date français
        import locale
        try:
            locale.setlocale(locale.LC_TIME, 'fr_FR.UTF-8')
        except Exception:
            try:
                locale.setlocale(locale.LC_TIME, 'French')
            except Exception:
                pass
        
        jours_fr = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]
        mois_fr = ["janvier", "février", "mars", "avril", "mai", "juin",
                   "juillet", "août", "septembre", "octobre", "novembre", "décembre"]
        now = datetime.now()
        date_str = f"📅 {jours_fr[now.weekday()]} {now.day} {mois_fr[now.month-1]} {now.year}"
        
        yield Header(show_clock=True)
        
        # Barre de mise à jour (masquée par défaut)
        with Horizontal(id="update-bar"):
            yield Static("🔄 Nouvelle version disponible !", id="update-text")
            yield Button("📥 Télécharger", id="btn-download-update")
            yield Button("✕", id="btn-dismiss-update")
        
        with Horizontal(id="welcome-bar"):
            yield Static("👋 Bienvenue !", id="welcome-text")
            yield Static(f"{date_str}  •  v{APP_VERSION}", id="welcome-date")
            yield Button("⚙️ Paramètres", id="btn-settings-header")
        
        with Grid(id="dashboard-grid"):
            yield DashboardCard("Emploi du temps", "📅", "btn-edt", "blue", id="card-edt")
            yield DashboardCard("Notes & Moyennes", "📝", "btn-notes", "green", id="card-notes")
            yield DashboardCard("Devoirs", "📚", "btn-devoirs", "orange", id="card-devoirs")
        
        yield Footer()

    def on_mount(self) -> None:
        self._load_dashboard()
        self._check_updates()

    @work(thread=True)
    def _check_updates(self) -> None:
        """Vérifie les mises à jour en arrière-plan."""
        info = check_for_update()
        if info.get("update_available"):
            self.update_info = info
            self.app.call_from_thread(self._show_update_banner)
    
    def _show_update_banner(self) -> None:
        """Affiche la bannière de mise à jour."""
        try:
            update_bar = self.query_one("#update-bar")
            update_bar.add_class("visible")
            
            if self.update_info:
                version = self.update_info.get("latest_version", "?")
                text = self.query_one("#update-text", Static)
                text.update(f"🔄 Nouvelle version {version} disponible !")
        except Exception:
            pass

    def on_button_pressed(self, event: Button.Pressed) -> None:
        screens = {
            "btn-edt": "edt",
            "btn-notes": "notes",
            "btn-devoirs": "devoirs",
            "btn-settings-header": "settings",
        }
        if event.button.id in screens:
            self.app.push_screen(screens[event.button.id])
        elif event.button.id == "btn-download-update":
            # Ouvrir la page de téléchargement
            if self.update_info:
                url = self.update_info.get("download_url", DOWNLOAD_URL)
                if open_download_page(url):
                    self.notify("🌐 Ouverture du navigateur...")
                else:
                    self.notify("❌ Impossible d'ouvrir le navigateur", severity="error")
        elif event.button.id == "btn-dismiss-update":
            # Masquer la bannière
            try:
                self.query_one("#update-bar").remove_class("visible")
            except Exception:
                pass

    @work(thread=True)
    def _load_dashboard(self) -> None:
        c = self.app.client
        
        try:
            name = c.info.name
            self.app.call_from_thread(
                lambda: self.query_one("#welcome-text", Static).update(f"👋 Bienvenue, {name} !")
            )
        except Exception:
            pass
        
        self.app.call_from_thread(self._load_edt_summary)
        self.app.call_from_thread(self._load_notes_summary)
        self.app.call_from_thread(self._load_devoirs_summary)

    def _load_edt_summary(self) -> None:
        content = self.query_one("#content-btn-edt", Static)
        c = self.app.client
        
        try:
            today = date.today()
            lessons = c.lessons(today)
            
            if not lessons:
                content.update("📭 Pas de cours aujourd'hui\n\n🎉 Profite de ta journée !")
                return
            
            active = [l for l in lessons if not l.canceled]
            canceled = [l for l in lessons if l.canceled]
            
            text = f"📚 [bold cyan]{len(active)}[/] cours aujourd'hui\n"
            if canceled:
                text += f"❌ [bold red]{len(canceled)}[/] annulé(s)\n"
            text += "\n"
            
            now = datetime.now()
            upcoming = [l for l in active if l.start > now]
            if upcoming:
                next_l = min(upcoming, key=lambda x: x.start)
                subj = next_l.subject.name if next_l.subject else "?"
                time = next_l.start.strftime("%H:%M")
                text += f"⏰ Prochain:\n[bold green]{subj}[/] à {time}"
            else:
                text += "✅ [bold green]Journée terminée ![/]"
            
            content.update(text)
            
        except Exception as e:
            content.update(f"[red]❌ Erreur: {str(e)[:25]}[/]")

    def _load_notes_summary(self) -> None:
        content = self.query_one("#content-btn-notes", Static)
        c = self.app.client
        
        try:
            avg = None
            for p in c.periods:
                if hasattr(p, 'overall_average') and p.overall_average:
                    avg = p.overall_average
                    break
            
            text = ""
            if avg:
                try:
                    avg_num = float(str(avg).replace(",", "."))
                    if avg_num >= 14:
                        color = "green"
                    elif avg_num >= 10:
                        color = "yellow"
                    else:
                        color = "red"
                    text += f"📊 Moyenne: [bold {color}]{avg}[/]\n\n"
                except ValueError:
                    text += f"📊 Moyenne: [bold]{avg}[/]\n\n"
            
            grades = []
            try:
                if c.current_period and hasattr(c.current_period, 'grades'):
                    grades = list(c.current_period.grades)
            except Exception:
                pass
            
            if grades:
                recent = sorted(grades, key=lambda x: x.date if x.date else date.min, reverse=True)[:3]
                text += "📝 Dernières notes:\n"
                for g in recent:
                    subj = g.subject.name[:10] if g.subject else "?"
                    val = g.grade if g.grade else "?"
                    out = g.out_of if g.out_of else "20"
                    try:
                        pct = float(str(val).replace(",",".")) / float(str(out).replace(",","."))
                        color = "green" if pct >= 0.7 else "yellow" if pct >= 0.5 else "red"
                    except (ValueError, ZeroDivisionError):
                        color = "white"
                    text += f"  • {subj}: [{color}]{val}/{out}[/]\n"
            else:
                text += "Aucune note récente"
            
            content.update(text)
            
        except Exception as e:
            content.update(f"[red]❌ Erreur: {str(e)[:25]}[/]")

    def _load_devoirs_summary(self) -> None:
        content = self.query_one("#content-btn-devoirs", Static)
        c = self.app.client
        
        try:
            today = date.today()
            homework = c.homework(today, today + timedelta(days=14))
            
            if not homework:
                content.update("🎉 [bold green]Aucun devoir ![/]\n\n😎 Relax, tu es à jour")
                return
            
            pending = [h for h in homework if not (hasattr(h, 'done') and h.done)]
            done = [h for h in homework if hasattr(h, 'done') and h.done]
            
            text = f"📝 [bold orange]{len(pending)}[/] devoir(s) à faire\n"
            text += f"✅ [bold green]{len(done)}[/] terminé(s)\n\n"
            
            if pending:
                upcoming = sorted(pending, key=lambda x: x.date if x.date else date.max)[:2]
                text += "⏰ Prochains:\n"
                for h in upcoming:
                    subj = h.subject.name[:12] if h.subject else "?"
                    dt = h.date.strftime("%d/%m") if h.date else "?"
                    days_left = (h.date - today).days if h.date else 99
                    if days_left <= 1:
                        color = "red"
                    elif days_left <= 3:
                        color = "yellow"
                    else:
                        color = "white"
                    text += f"  • [{color}]{subj} ({dt})[/]\n"
            
            content.update(text)
            
        except Exception as e:
            content.update(f"[red]❌ Erreur: {str(e)[:25]}[/]")

    def action_refresh(self) -> None:
        self._load_dashboard()
        self.notify("🔄 Actualisation...")

    def action_logout(self) -> None:
        self.app.client = None
        self.app.pop_screen()
        self.notify("👋 Déconnecté")
    
    def action_settings(self) -> None:
        """Ouvre la page des paramètres"""
        self.app.push_screen("settings")


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRANS DÉTAILLÉS
# ═══════════════════════════════════════════════════════════════════════════════

class DetailScreen(Screen):
    """Base pour écrans détaillés"""
    
    BINDINGS = [
        Binding("escape", "back", "← Retour"),
        Binding("r", "refresh", "Actualiser"),
    ]

    CSS = """
    DetailScreen { layout: vertical; background: $surface; }
    
    #detail-header {
        height: 4;
        padding: 1 2;
        content-align: center middle;
    }
    
    .header-blue { background: $primary; }
    .header-green { background: $success; }
    .header-orange { background: $warning; }
    .header-red { background: $error; }
    
    #detail-title { text-style: bold; color: $text; }
    
    #period-bar {
        height: 5;
        min-height: 5;
        background: $surface-darken-1;
        padding: 1;
        align: left middle;
    }
    
    #period-bar Button {
        margin: 0 1;
        min-width: 12;
        background: $success;
    }
    
    #period-bar Button:hover {
        background: $success-darken-1;
    }
    
    #period-label {
        width: auto;
        padding: 0 1;
        text-style: bold;
        content-align: center middle;
    }
    
    #week-nav {
        height: 5;
        min-height: 5;
        background: $surface-darken-1;
        padding: 1;
        align: center middle;
    }
    
    #week-nav Button {
        margin: 0 1;
        min-width: 14;
    }
    
    #week-nav #btn-prev-week {
        background: $primary;
    }
    
    #week-nav #btn-next-week {
        background: $primary;
    }
    
    #week-nav #btn-today {
        background: $success;
    }
    
    #week-label {
        width: auto;
        min-width: 35;
        padding: 0 2;
        text-style: bold;
        text-align: center;
        content-align: center middle;
        color: $text;
    }
    
    #detail-content { height: 1fr; padding: 1 2; }
    
    /* Items */
    .day-header {
        background: $primary-darken-1; 
        padding: 0 1;
        text-style: bold; 
        margin-top: 1;
        color: $text;
    }
    .day-today { background: $success; }
    
    .item { 
        padding: 1; 
        background: $panel; 
        border-left: thick $primary; 
        margin-bottom: 1;
    }
    .item-canceled { border-left: thick $error; background: $error 15%; }
    .item-done { border-left: thick $success; background: $success 15%; }
    .item-warning { border-left: thick $warning; background: $warning 15%; }
    .item-error { border-left: thick $error; background: $error 15%; }
    .item-good { border-left: thick $success; }
    .item-medium { border-left: thick $warning; }
    .item-bad { border-left: thick $error; }
    
    .section { 
        background: $primary; 
        padding: 0 1; 
        text-style: bold; 
        margin: 1 0;
        color: $text;
    }
    .section-green { background: $success; }
    .section-orange { background: $warning; }
    .section-red { background: $error; }
    
    .empty { text-align: center; color: $text-muted; padding: 2; }
    .error { color: $error; padding: 1; }
    """

    def action_back(self) -> None:
        self.app.pop_screen()

    def action_refresh(self) -> None:
        self.load_data()
        self.notify("🔄 Actualisation...")

    def load_data(self) -> None:
        pass


class EdtScreen(DetailScreen):
    """Emploi du temps avec navigation par semaine"""
    
    week_offset = 0  # 0 = semaine actuelle, -1 = semaine précédente, +1 = semaine suivante

    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="detail-header", classes="header-blue"):
            yield Static("📅 EMPLOI DU TEMPS", id="detail-title")
        with Horizontal(id="week-nav"):
            yield Button("◀ Précédent", id="btn-prev-week", variant="default")
            yield Static("Semaine du ...", id="week-label")
            yield Button("Aujourd'hui", id="btn-today", variant="primary")
            yield Button("Suivant ▶", id="btn-next-week", variant="default")
        yield ScrollableContainer(id="detail-content")
        yield Footer()

    def on_mount(self) -> None:
        self.week_offset = 0
        self.load_data()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id
        if btn_id == "btn-prev-week":
            self.week_offset -= 1
            self.load_data()
        elif btn_id == "btn-next-week":
            self.week_offset += 1
            self.load_data()
        elif btn_id == "btn-today":
            self.week_offset = 0
            self.load_data()

    @work(thread=True)
    def load_data(self) -> None:
        self.app.call_from_thread(self._load)

    def _load(self) -> None:
        scroll = self.query_one("#detail-content", ScrollableContainer)
        for child in list(scroll.children):
            child.remove()
        
        c = self.app.client
        
        try:
            today = date.today()
            # Calculer la semaine en fonction de l'offset
            base_date = today + timedelta(weeks=self.week_offset)
            start = base_date - timedelta(days=base_date.weekday())
            end = start + timedelta(days=6)
            
            # Mettre à jour le label de la semaine
            week_label = self.query_one("#week-label", Static)
            if self.week_offset == 0:
                week_label.update(f"📅 Semaine du {start.strftime('%d/%m')} au {end.strftime('%d/%m')} (actuelle)")
            else:
                week_label.update(f"📅 Semaine du {start.strftime('%d/%m')} au {end.strftime('%d/%m')}")
            
            lessons = c.lessons(
                datetime.combine(start, datetime.min.time()),
                datetime.combine(end, datetime.max.time())
            )
            
            if not lessons:
                scroll.mount(Static("📭 Aucun cours cette semaine", classes="empty"))
                return
            
            days = {}
            names = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]
            
            for l in lessons:
                d = l.start.date()
                if d not in days:
                    days[d] = []
                days[d].append(l)
            
            for d in sorted(days.keys()):
                is_today = d == today
                cls = "day-header day-today" if is_today else "day-header"
                marker = "📍 " if is_today else ""
                scroll.mount(Static(f"{marker}{names[d.weekday()]} {d.strftime('%d/%m')}", classes=cls))
                
                for l in sorted(days[d], key=lambda x: x.start):
                    time = f"{l.start.strftime('%H:%M')} - {l.end.strftime('%H:%M')}"
                    subj = l.subject.name if l.subject else "?"
                    room = l.classroom if l.classroom else "?"
                    teacher = l.teacher_name if l.teacher_name else "?"
                    
                    text = f"[bold cyan]⏰ {time}[/]\n"
                    text += f"[bold]📚 {subj}[/]\n"
                    text += f"[dim]🚪 {room} │ 👨‍🏫 {teacher}[/]"
                    
                    if l.canceled:
                        text += "\n[bold red]❌ COURS ANNULÉ[/]"
                        item_cls = "item item-canceled"
                    elif l.status:
                        text += f"\n[bold yellow]⚠️ {l.status}[/]"
                        item_cls = "item item-warning"
                    else:
                        item_cls = "item"
                    
                    scroll.mount(Static(text, classes=item_cls))
                    
        except Exception as e:
            scroll.mount(Static(f"[red]❌ Erreur: {e}[/]", classes="error"))


class NotesScreen(DetailScreen):
    """Notes avec sélection de période"""
    
    selected_period_idx = 0
    filtered_periods = []

    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="detail-header", classes="header-green"):
            yield Static("📝 NOTES & MOYENNES", id="detail-title")
        with Horizontal(id="period-bar"):
            yield Static("📆 Période: ", id="period-label")
            yield Button("P1", id="btn-p1", variant="primary")
            yield Button("P2", id="btn-p2", variant="default")
            yield Button("P3", id="btn-p3", variant="default")
        yield ScrollableContainer(id="detail-content")
        yield Footer()

    def on_mount(self) -> None:
        self.selected_period_idx = 0
        self._init_periods()
        self._setup_buttons()
        self.load_data()

    def _setup_buttons(self) -> None:
        """Configure les boutons selon la config"""
        config = self.app.config
        period_type = config.get("period_type", "trimestre")
        
        btn1 = self.query_one("#btn-p1", Button)
        btn2 = self.query_one("#btn-p2", Button)
        btn3 = self.query_one("#btn-p3", Button)
        
        if period_type == "semestre":
            btn1.label = "Semestre 1"
            btn2.label = "Semestre 2"
            btn3.display = False
        else:
            btn1.label = "Trimestre 1"
            btn2.label = "Trimestre 2"
            btn3.label = "Trimestre 3"
            btn3.display = True
        
        # Mettre à jour avec les vrais noms si disponibles
        self._update_buttons()

    def _init_periods(self) -> None:
        """Initialise les périodes filtrées"""
        c = self.app.client
        config = self.app.config
        period_type = config.get("period_type", "trimestre")
        
        # Filtrer les périodes selon le type configuré
        filtered_periods = []
        for i, p in enumerate(c.periods):
            name = p.name.lower() if p.name else ""
            if period_type == "trimestre" and ("trimestre" in name or "t1" in name or "t2" in name or "t3" in name):
                filtered_periods.append((i, p))
            elif period_type == "semestre" and ("semestre" in name or "s1" in name or "s2" in name):
                filtered_periods.append((i, p))
        
        # Si aucune période filtrée, prendre toutes les périodes
        if not filtered_periods:
            filtered_periods = [(i, p) for i, p in enumerate(c.periods)]
        
        self.filtered_periods = filtered_periods

    def _update_buttons(self) -> None:
        """Met à jour le texte et la visibilité des boutons"""
        config = self.app.config
        period_type = config.get("period_type", "trimestre")
        
        btns = [self.query_one("#btn-p1", Button), self.query_one("#btn-p2", Button)]
        
        # Ajouter le 3ème bouton seulement si trimestre
        try:
            btn3 = self.query_one("#btn-p3", Button)
            btns.append(btn3)
        except Exception:
            pass
        
        for i, btn in enumerate(btns):
            if i < len(self.filtered_periods):
                _, period = self.filtered_periods[i]
                name = period.name if period.name else f"Période {i+1}"
                btn.label = name[:15]
                btn.display = True
                btn.variant = "primary" if i == self.selected_period_idx else "default"
            else:
                btn.display = False

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_map = {"btn-p1": 0, "btn-p2": 1, "btn-p3": 2}
        if event.button.id in btn_map:
            self.selected_period_idx = btn_map[event.button.id]
            self._update_buttons()
            self._load_period_data()
    
    @work(thread=True)
    def load_data(self) -> None:
        self.app.call_from_thread(self._load_period_data)

    def _load_period_data(self) -> None:
        """Charge les données de la période sélectionnée"""
        scroll = self.query_one("#detail-content", ScrollableContainer)
        for child in list(scroll.children):
            child.remove()
        
        c = self.app.client
        
        try:
            if not hasattr(self, 'filtered_periods') or not self.filtered_periods:
                scroll.mount(Static("Aucune période disponible", classes="empty"))
                return
            
            # Récupérer la période sélectionnée
            real_idx, period = self.filtered_periods[self.selected_period_idx]
            
            period_name = period.name if period.name else "Période"
            period_start = period.start.strftime("%d/%m/%Y") if period.start else ""
            period_end = period.end.strftime("%d/%m/%Y") if period.end else ""
            
            # En-tête de la période
            scroll.mount(Static(
                f"📆 {period_name}\n   Du {period_start} au {period_end}",
                classes="section"
            ))
            
            # Moyenne générale de la période
            try:
                if hasattr(period, 'overall_average') and period.overall_average:
                    avg = period.overall_average
                    class_avg = period.class_overall_average if hasattr(period, 'class_overall_average') else "?"
                    
                    try:
                        avg_num = float(str(avg).replace(",", "."))
                        if avg_num >= 14:
                            color = "green"
                        elif avg_num >= 10:
                            color = "yellow"
                        else:
                            color = "red"
                    except ValueError:
                        color = "white"
                    
                    text = f"[bold]📊 MOYENNE GÉNÉRALE[/]\n"
                    text += f"   Toi: [bold {color}]{avg}[/] │ Classe: {class_avg}"
                    scroll.mount(Static(text, classes="item"))
            except Exception:
                pass
            
            # Moyennes par matière
            scroll.mount(Static("📚 Moyennes par matière", classes="section section-green"))
            
            has_avg = False
            try:
                if hasattr(period, 'averages') and period.averages:
                    for a in period.averages:
                        has_avg = True
                        subj = a.subject.name if a.subject else "?"
                        stu = a.student if a.student else "?"
                        cls_avg = a.class_average if a.class_average else "?"
                        out = a.out_of if a.out_of else "20"
                        
                        try:
                            pct = float(str(stu).replace(",",".")) / float(str(out).replace(",","."))
                            if pct >= 0.7:
                                color, item_cls = "green", "item item-good"
                            elif pct >= 0.5:
                                color, item_cls = "yellow", "item item-medium"
                            else:
                                color, item_cls = "red", "item item-bad"
                        except (ValueError, ZeroDivisionError):
                            color, item_cls = "white", "item"
                        
                        text = f"[bold]📖 {subj}[/]\n"
                        text += f"   Toi: [bold {color}]{stu}/{out}[/] │ Classe: {cls_avg}"
                        scroll.mount(Static(text, classes=item_cls))
            except Exception:
                pass
            
            if not has_avg:
                scroll.mount(Static("Aucune moyenne pour cette période", classes="empty"))
            
            # Notes de la période
            scroll.mount(Static("📝 Notes de la période", classes="section section-green"))
            
            grades = []
            try:
                if hasattr(period, 'grades') and period.grades:
                    grades = list(period.grades)
            except Exception:
                pass
            
            if not grades:
                scroll.mount(Static("Aucune note pour cette période", classes="empty"))
            else:
                for g in sorted(grades, key=lambda x: x.date if x.date else date.min, reverse=True):
                    subj = g.subject.name if g.subject else "?"
                    val = g.grade if g.grade else "?"
                    out = g.out_of if g.out_of else "20"
                    coef = g.coefficient if g.coefficient else "1"
                    dt = g.date.strftime("%d/%m/%Y") if g.date else "?"
                    comment = g.comment if hasattr(g, 'comment') and g.comment else ""
                    
                    try:
                        pct = float(str(val).replace(",",".")) / float(str(out).replace(",","."))
                        if pct >= 0.7:
                            color, item_cls = "green", "item item-good"
                        elif pct >= 0.5:
                            color, item_cls = "yellow", "item item-medium"
                        else:
                            color, item_cls = "red", "item item-bad"
                    except (ValueError, ZeroDivisionError):
                        color, item_cls = "white", "item"
                    
                    text = f"[bold]📖 {subj}[/]\n"
                    text += f"   [bold {color}]{val}/{out}[/] (coef {coef}) │ {dt}"
                    if comment:
                        text += f"\n   [dim]💬 {comment[:50]}[/]"
                    
                    scroll.mount(Static(text, classes=item_cls))
                    
        except Exception as e:
            scroll.mount(Static(f"[red]❌ Erreur: {e}[/]", classes="error"))


class DevoirsScreen(DetailScreen):
    """Devoirs"""

    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="detail-header", classes="header-orange"):
            yield Static("📚 DEVOIRS", id="detail-title")
        yield ScrollableContainer(id="detail-content")
        yield Footer()

    def on_mount(self) -> None:
        self.load_data()

    @work(thread=True)
    def load_data(self) -> None:
        self.app.call_from_thread(self._load)

    def _load(self) -> None:
        scroll = self.query_one("#detail-content", ScrollableContainer)
        for child in list(scroll.children):
            child.remove()
        
        c = self.app.client
        
        try:
            today = date.today()
            homework = c.homework(today, today + timedelta(days=60))
            
            if not homework:
                scroll.mount(Static("🎉 Aucun devoir à venir !", classes="empty"))
                return
            
            pending = [h for h in homework if not (hasattr(h, 'done') and h.done)]
            done_list = [h for h in homework if hasattr(h, 'done') and h.done]
            
            if pending:
                scroll.mount(Static(f"📝 À FAIRE ({len(pending)})", classes="section section-orange"))
                for h in sorted(pending, key=lambda x: x.date if x.date else date.max):
                    subj = h.subject.name if h.subject else "?"
                    dt = h.date.strftime("%A %d/%m") if h.date else "?"
                    desc = h.description if h.description else "Pas de description"
                    days_left = (h.date - today).days if h.date else 99
                    
                    if days_left <= 1:
                        urgency = "[bold red]⚠️ URGENT[/]"
                        item_cls = "item item-error"
                    elif days_left <= 3:
                        urgency = "[yellow]⏰ Bientôt[/]"
                        item_cls = "item item-warning"
                    else:
                        urgency = ""
                        item_cls = "item"
                    
                    text = f"[bold orange]📅 {dt}[/] {urgency}\n"
                    text += f"[bold]📖 {subj}[/]\n"
                    text += f"[dim]{desc[:150]}[/]"
                    scroll.mount(Static(text, classes=item_cls))
            
            if done_list:
                scroll.mount(Static(f"✅ TERMINÉS ({len(done_list)})", classes="section section-green"))
                for h in sorted(done_list, key=lambda x: x.date if x.date else date.max)[:10]:
                    subj = h.subject.name if h.subject else "?"
                    dt = h.date.strftime("%d/%m") if h.date else "?"
                    
                    text = f"[green]✅ {subj}[/] ({dt})"
                    scroll.mount(Static(text, classes="item item-done"))
                    
        except Exception as e:
            scroll.mount(Static(f"[red]❌ Erreur: {e}[/]", classes="error"))


class VieScreen(DetailScreen):
    """Vie scolaire"""

    def compose(self) -> ComposeResult:
        yield Header()
        with Container(id="detail-header", classes="header-red"):
            yield Static("🚫 VIE SCOLAIRE", id="detail-title")
        yield ScrollableContainer(id="detail-content")
        yield Footer()

    def on_mount(self) -> None:
        self.load_data()

    @work(thread=True)
    def load_data(self) -> None:
        self.app.call_from_thread(self._load)

    def _load(self) -> None:
        scroll = self.query_one("#detail-content", ScrollableContainer)
        for child in list(scroll.children):
            child.remove()
        
        c = self.app.client
        
        try:
            scroll.mount(Static("🚫 ABSENCES", classes="section section-red"))
            
            has_abs = False
            for p in c.periods:
                try:
                    if hasattr(p, 'absences'):
                        for a in p.absences:
                            has_abs = True
                            if a.justified:
                                just = "[green]✅ Justifiée[/]"
                                item_cls = "item"
                            else:
                                just = "[red]❌ Non justifiée[/]"
                                item_cls = "item item-error"
                            
                            from_d = a.from_date.strftime("%d/%m/%Y %H:%M") if a.from_date else "?"
                            to_d = a.to_date.strftime("%H:%M") if a.to_date else "?"
                            reason = a.reasons[0] if a.reasons else "Pas de motif"
                            
                            text = f"[bold]📅 {from_d} → {to_d}[/]\n{just}\n[dim]📝 {reason}[/]"
                            scroll.mount(Static(text, classes=item_cls))
                except Exception:
                    pass
            
            if not has_abs:
                scroll.mount(Static("✨ Aucune absence !", classes="empty"))
            
            scroll.mount(Static("⏰ RETARDS", classes="section section-orange"))
            
            has_del = False
            for p in c.periods:
                try:
                    if hasattr(p, 'delays'):
                        for d in p.delays:
                            has_del = True
                            if d.justified:
                                just = "[green]✅ Justifié[/]"
                                item_cls = "item"
                            else:
                                just = "[yellow]❌ Non justifié[/]"
                                item_cls = "item item-warning"
                            
                            dt = d.date.strftime("%d/%m/%Y") if d.date else "?"
                            mins = f"{d.minutes} minutes" if hasattr(d, 'minutes') else "?"
                            reason = d.reasons[0] if d.reasons else "Pas de motif"
                            
                            text = f"[bold]📅 {dt} - {mins}[/]\n{just}\n[dim]📝 {reason}[/]"
                            scroll.mount(Static(text, classes=item_cls))
                except Exception:
                    pass
            
            if not has_del:
                scroll.mount(Static("✨ Aucun retard !", classes="empty"))
                
        except Exception as e:
            scroll.mount(Static(f"[red]❌ Erreur: {e}[/]", classes="error"))


# ═══════════════════════════════════════════════════════════════════════════════
# ÉCRAN PARAMÈTRES
# ═══════════════════════════════════════════════════════════════════════════════

class SettingsScreen(Screen):
    """Page des paramètres"""
    
    BINDINGS = [
        Binding("escape", "back", "← Retour"),
    ]
    
    CSS = """
    SettingsScreen {
        align: center middle;
        background: $surface;
    }
    
    #settings-container {
        width: 90;
        height: auto;
        max-height: 95%;
        overflow-y: auto;
    }
    
    #settings-header {
        width: 100%;
        height: 5;
        background: $accent;
        border: round $accent;
        margin-bottom: 1;
    }
    
    #settings-title {
        text-align: center;
        width: 100%;
        text-style: bold;
        color: $text;
        padding-top: 1;
    }
    
    #settings-subtitle {
        text-align: center;
        width: 100%;
        color: $text-muted;
    }
    
    .settings-section {
        width: 100%;
        height: auto;
        background: $panel;
        border: round $primary-darken-1;
        padding: 2;
        margin-bottom: 1;
    }
    
    .section-title {
        text-style: bold;
        color: $primary;
        margin-bottom: 1;
    }
    
    .section-description {
        color: $text-muted;
        margin-bottom: 1;
    }
    
    .setting-row {
        layout: horizontal;
        height: auto;
        width: 100%;
        margin-bottom: 1;
        align: left middle;
    }
    
    .setting-label {
        width: 40%;
        color: $text;
    }
    
    .setting-value {
        width: 60%;
    }
    
    .setting-buttons {
        layout: horizontal;
        height: auto;
        width: 60%;
    }
    
    .setting-button {
        margin: 0 1;
        min-width: 15;
    }
    
    .danger-section {
        background: $error-darken-3;
        border: round $error;
    }
    
    .danger-button {
        background: $error;
    }
    
    .current-value {
        color: $success;
        text-style: bold;
    }
    """
    
    def compose(self) -> ComposeResult:
        config = load_config()
        creds = load_credentials()
        current_period = config.get("period_type", "Non configuré")
        has_creds = bool(creds.get("url"))
        
        with ScrollableContainer(id="settings-container"):
            # Header
            with Vertical(id="settings-header"):
                yield Static("⚙️ PARAMÈTRES", id="settings-title")
                yield Static("Personnalise ton expérience Pynote", id="settings-subtitle")
            
            # Section Période
            with Vertical(classes="settings-section"):
                yield Static("📚 Type de période", classes="section-title")
                yield Static("Change l'organisation de tes notes", classes="section-description")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Période actuelle:", classes="setting-label")
                    if current_period == "trimestre":
                        yield Static("📅 Trimestres", classes="setting-value current-value", id="period-display")
                    elif current_period == "semestre":
                        yield Static("📅 Semestres", classes="setting-value current-value", id="period-display")
                    else:
                        yield Static("❓ Non configuré", classes="setting-value", id="period-display")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Modifier:", classes="setting-label")
                    with Horizontal(classes="setting-buttons"):
                        yield Button("📅 Trimestres", id="btn-set-trimestre", classes="setting-button")
                        yield Button("📅 Semestres", id="btn-set-semestre", classes="setting-button")
            
            # Section Compte
            with Vertical(classes="settings-section"):
                yield Static("👤 Compte Pronote", classes="section-title")
                yield Static("Gère tes identifiants de connexion", classes="section-description")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Statut:", classes="setting-label")
                    if has_creds:
                        yield Static(f"✅ Identifiants sauvegardés\n[dim]URL: {creds.get('url', '?')[:40]}...\nUtilisateur: {creds.get('username', '?')}[/]", classes="setting-value")
                    else:
                        yield Static("❌ Aucun identifiant", classes="setting-value")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Actions:", classes="setting-label")
                    with Horizontal(classes="setting-buttons"):
                        yield Button("✏️ Modifier", id="btn-change-account", classes="setting-button")
                        if has_creds:
                            yield Button("🗑️ Supprimer", id="btn-delete-creds", classes="setting-button danger-button")
            
            # Section Apparence
            with Vertical(classes="settings-section"):
                yield Static("🎨 Apparence", classes="section-title")
                yield Static("Personnalise l'interface", classes="section-description")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Thème:", classes="setting-label")
                    theme_text = "🌙 Sombre" if self.app.theme == "textual-dark" else "☀️ Clair"
                    yield Static(theme_text, classes="setting-value current-value", id="theme-display")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Changer:", classes="setting-label")
                    with Horizontal(classes="setting-buttons"):
                        yield Button("🔄 Basculer thème", id="btn-toggle-theme", classes="setting-button")
            
            # Section Informations
            with Vertical(classes="settings-section"):
                yield Static("ℹ️ Informations", classes="section-title")
                yield Static(f"Version: {APP_VERSION}", classes="section-description")
                yield Static(f"Fichier config: {CONFIG_FILE}", classes="section-description")
                yield Static(f"Fichier identifiants: {CREDENTIALS_FILE}", classes="section-description")
            
            # Section Danger
            with Vertical(classes="settings-section danger-section"):
                yield Static("⚠️ Zone dangereuse", classes="section-title")
                yield Static("Actions irréversibles", classes="section-description")
                
                with Horizontal(classes="setting-row"):
                    yield Static("Réinitialiser:", classes="setting-label")
                    with Horizontal(classes="setting-buttons"):
                        yield Button("🔥 Effacer config", id="btn-reset-config", classes="setting-button danger-button")
                        yield Button("🚪 Déconnexion", id="btn-logout", classes="setting-button danger-button")
    
    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Gère les actions des boutons"""
        btn_id = event.button.id
        
        # Période
        if btn_id == "btn-set-trimestre":
            save_config({"period_type": "trimestre"})
            self.app.config = {"period_type": "trimestre"}
            
            # Mettre à jour l'affichage
            try:
                period_display = self.query_one("#period-display", Static)
                period_display.update("📅 Trimestres")
                period_display.add_class("current-value")
            except Exception:
                pass
            
            self.notify("✅ Période changée en Trimestres")
            
        elif btn_id == "btn-set-semestre":
            save_config({"period_type": "semestre"})
            self.app.config = {"period_type": "semestre"}
            
            # Mettre à jour l'affichage
            try:
                period_display = self.query_one("#period-display", Static)
                period_display.update("📅 Semestres")
                period_display.add_class("current-value")
            except Exception:
                pass
            
            self.notify("✅ Période changée en Semestres")
        
        # Compte
        elif btn_id == "btn-change-account":
            self.app.client = None
            delete_credentials()
            self.app.pop_screen()
            self.app.pop_screen()
            self.app.push_screen("login")
            self.notify("🔄 Reconnectez-vous avec un nouveau compte")
            
        elif btn_id == "btn-delete-creds":
            delete_credentials()
            self.notify("🗑️ Identifiants supprimés")
            self.refresh()
        
        # Apparence
        elif btn_id == "btn-toggle-theme":
            if self.app.theme == "textual-dark":
                self.app.theme = "textual-light"
                theme_text = "☀️ Clair"
            else:
                self.app.theme = "textual-dark"
                theme_text = "🌙 Sombre"
            
            theme_display = self.query_one("#theme-display", Static)
            theme_display.update(theme_text)
            self.notify(f"🎨 Thème changé: {theme_text}")
        
        # Danger
        elif btn_id == "btn-reset-config":
            if CONFIG_FILE.exists():
                CONFIG_FILE.unlink()
            self.app.config = {}
            self.notify("🔥 Configuration réinitialisée")
            self.refresh()
            
        elif btn_id == "btn-logout":
            self.app.client = None
            self.app.pop_screen()
            self.app.pop_screen()
            self.notify("👋 Déconnecté")
    
    def action_back(self) -> None:
        """Retour au dashboard"""
        self.app.pop_screen()


# ═══════════════════════════════════════════════════════════════════════════════
# APPLICATION
# ═══════════════════════════════════════════════════════════════════════════════

class PynoteApp(App):
    """Application Pynote - Client Pronote coloré"""

    TITLE = "🎓 Pynote"
    
    BINDINGS = [
        Binding("ctrl+q", "quit", "Quitter", priority=True),
        Binding("ctrl+t", "toggle_dark", "Thème", priority=True),
    ]

    SCREENS = {
        "license": LicenseScreen,
        "login": LoginScreen,
        "config": ConfigScreen,
        "dashboard": DashboardScreen,
        "settings": SettingsScreen,
        "edt": EdtScreen,
        "notes": NotesScreen,
        "devoirs": DevoirsScreen,
        "vie": VieScreen,
    }

    def __init__(self):
        super().__init__()
        self.client = None
        self.config = load_config()

    def on_mount(self) -> None:
        if is_license_accepted():
            self.push_screen("login")
        else:
            self.push_screen("license")

    def action_toggle_dark(self) -> None:
        self.theme = "textual-dark" if self.theme == "textual-light" else "textual-light"


if __name__ == "__main__":
    PynoteApp().run()
